<?php
/**
 * Uninstall Volade Breadcrumbs.
 *
 * Removes the settings and transients this plugin owns when uninstalled.
 *
 * The six settings Volade shares across the whole suite (API base URL, premium
 * endpoint, API key, licence key, upgrade URL and interface language) are
 * deliberately left behind: one licence covers every Volade plugin, so
 * removing Breadcrumbs must not strip the credentials of a sibling plugin that
 * is still installed. They only ever leave the database when the last plugin
 * of the suite goes, or by hand from Settings.
 *
 * The list below must stay in step with Volade_Breadcrumbs_Tools::OPTIONS.
 *
 * @package Volade
 */

// If uninstall not called from WordPress, exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Settings this plugin owns on its own.
$volade_bc_options = array(
	'volade_bc_enabled',
	'volade_bc_post_types',
	'volade_bc_show_home',
	'volade_bc_home',
	'volade_bc_hide_home',
	'volade_bc_separator',
	'volade_bc_style',
	'volade_bc_depth',
	'volade_bc_schema',
	'volade_bc_hide_title',
	'volade_bc_woo',
);

// The suite's "Getting started" marker is a local flag, never sent anywhere,
// so it goes with the plugin that set it.
$volade_bc_options[] = 'volade_configured';

foreach ( $volade_bc_options as $volade_bc_option ) {
	delete_option( $volade_bc_option );
}

// Per-item decision stored in the editor's meta box.
delete_post_meta_by_key( '_volade_bc_hide' );

// Transients this plugin owns.
delete_transient( 'volade_bc_premium_status' );
delete_transient( 'volade_bc_last_test' );
