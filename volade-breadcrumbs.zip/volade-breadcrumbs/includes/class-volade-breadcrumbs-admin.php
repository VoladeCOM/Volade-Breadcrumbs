<?php
/**
 * Admin menu and settings screens.
 *
 * Top-level menu on the left:
 * Volade > Volade (overview), Settings, License, Language, Tools, About.
 *
 * @package Volade
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Volade_Breadcrumbs_Admin {

	/**
	 * Parent menu slug.
	 */
	const SLUG = 'volade-breadcrumbs';

	/**
	 * Screen registry: slug => view id + sub-menu icon class.
	 *
	 * The 'icon' value is a modifier class consumed by assets/css/menu.css,
	 * which maps it to a Dashicon codepoint for the sub-menu link.
	 *
	 * @var array
	 */
	const SCREENS = array(
		'volade-breadcrumbs'          => array( 'view' => 'overview', 'icon' => 'volade-subicon-home' ),
		'volade-breadcrumbs-settings' => array( 'view' => 'settings',  'icon' => 'volade-subicon-settings' ),
		'volade-breadcrumbs-license'  => array( 'view' => 'license',   'icon' => 'volade-subicon-license' ),
		'volade-breadcrumbs-language' => array( 'view' => 'language',  'icon' => 'volade-subicon-language' ),
		'volade-breadcrumbs-tools'    => array( 'view' => 'tools',     'icon' => 'volade-subicon-tools' ),
		'volade-breadcrumbs-about'    => array( 'view' => 'about',     'icon' => 'volade-subicon-about' ),
	);

	/**
	 * @var Volade_Breadcrumbs_Admin
	 */
	private static $instance;

	/**
	 * @return Volade_Breadcrumbs_Admin
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ), 9 );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_init', array( $this, 'mark_setup_step' ) );
		add_action( 'updated_option', array( $this, 'relay_option_update' ), 10, 3 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_hide_metabox' ), 10, 1 );
		add_action( 'save_post', array( $this, 'save_hide_metabox' ), 10, 2 );
		add_filter( 'plugin_action_links_' . plugin_basename( VOLADE_BREADCRUMBS_PLUGIN_FILE ), array( $this, 'plugin_action_links' ) );
		add_filter( 'plugin_row_meta', array( $this, 'plugin_row_meta' ), 10, 2 );

		/*
		 * Settings backup runs through admin-post rather than the screen
		 * itself: the download has to stream a body (so it cannot render a
		 * page first), and the two write operations need the
		 * Post/Redirect/Get cycle the other Tools actions already use.
		 */
		add_action( 'admin_post_volade-breadcrumbs_export_settings', array( 'Volade_Breadcrumbs_Tools', 'handle_export' ) );
		add_action( 'admin_post_volade-breadcrumbs_import_settings', array( 'Volade_Breadcrumbs_Tools', 'handle_import' ) );
		add_action( 'admin_post_volade-breadcrumbs_restore_defaults', array( 'Volade_Breadcrumbs_Tools', 'handle_restore' ) );
	}

	/**
	 * Capability required to see and use every Volade screen.
	 *
	 * Filterable so a site can hand the screens to a custom role without
	 * editing the plugin. The default is the same capability WordPress.org
	 * expects of any settings screen.
	 *
	 * @return string
	 */
	public static function capability() {
		/**
		 * Capability needed to access Volade.
		 *
		 * @param string $capability Capability slug, default manage_options.
		 */
		return (string) apply_filters( 'volade_admin_capability', 'manage_options' );
	}

	/**
	 * Record that the Settings screen was saved (drives the Overview checklist).
	 *
	 * options.php redirects back with settings-updated=true whenever the form
	 * submitted without errors, which is the only moment a visitor can honestly
	 * be said to have configured the connection. Activation writes the same
	 * options through add_option(), so it never fires this and never counts.
	 */
	public function mark_setup_step() {
		if ( empty( $_GET['settings-updated'] ) || empty( $_GET['page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- PRG flag of our own settings screen; no form is processed here, both values are compared to literals.
			return;
		}

		$page = sanitize_key( wp_unslash( $_GET['page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification -- screen slug only, compared against a literal below.

		if ( 'volade-breadcrumbs-settings' !== $page || ! current_user_can( self::capability() ) ) {
			return;
		}

		if ( get_option( Volade_Breadcrumbs_Tools::SETUP_OPTION ) ) {
			return;
		}

		update_option( Volade_Breadcrumbs_Tools::SETUP_OPTION, time() );
	}

	/**
	 * Relay changes of our own options to a public action.
	 *
	 * @param string $option    Option name.
	 * @param mixed  $old_value Previous value.
	 * @param mixed  $value     New value.
	 */
	public function relay_option_update( $option, $old_value, $value ) {
		if ( ! isset( Volade_Breadcrumbs_Tools::OPTIONS[ $option ] ) && Volade_Breadcrumbs_Tools::SETUP_OPTION !== $option ) {
			return;
		}

		do_action( 'volade_option_updated', $option, $old_value, $value );
	}

	/**
	 * Register the left-side menu.
	 */
	public function add_menu() {
		$cap = self::capability();

		/*
		 * Top-level menu (left sidebar).
		 *
		 * The 6th argument must be the literal string 'none', not an empty
		 * string: with '' WordPress falls back to 'dashicons-admin-generic' AND
		 * adds the class menu-icon-generic, which carries this core rule:
		 *
		 *     .menu-icon-generic div.wp-menu-image { background-image: none !important; }
		 *
		 * That !important was wiping out the branded logo drawn in menu.css.
		 * 'none' is the documented core way to say "I style the icon myself".
		 */
		add_menu_page(
			esc_html__( 'Volade Breadcrumbs', 'volade-breadcrumbs' ),
			esc_html__( 'Volade Breadcrumbs', 'volade-breadcrumbs' ),
			$cap,
			self::SLUG,
			array( $this, 'render_page' ),
			'none',
			27
		);

		$submenus = array(
			'volade-breadcrumbs-settings' => esc_html__( 'Settings', 'volade-breadcrumbs' ),
			'volade-breadcrumbs-license'  => esc_html__( 'License', 'volade-breadcrumbs' ),
			'volade-breadcrumbs-language' => esc_html__( 'Language', 'volade-breadcrumbs' ),
			'volade-breadcrumbs-tools'    => esc_html__( 'Tools', 'volade-breadcrumbs' ),
			'volade-breadcrumbs-about'    => esc_html__( 'About', 'volade-breadcrumbs' ),
		);

		foreach ( $submenus as $slug => $title ) {
			add_submenu_page(
				self::SLUG,
				$title,
				$title,
				$cap,
				$slug,
				array( $this, 'render_page' )
			);
		}

		$this->add_submenu_icons();
	}

	/**
	 * Attach an icon class to every sub-menu entry.
	 *
	 * WordPress renders no icon on sub-menu links, but menu-header.php does read
	 * a 5th slot on each $submenu row ("4 = classes") and prints it on the <li>.
	 * add_submenu_page() never creates that slot, so we append it here and let
	 * assets/css/menu.css draw a Dashicon for each class.
	 *
	 * @see https://developer.wordpress.org/reference/functions/add_submenu_page/
	 */
	private function add_submenu_icons() {
		global $submenu;

		if ( ! isset( $submenu[ self::SLUG ] ) || ! is_array( $submenu[ self::SLUG ] ) ) {
			return;
		}

		foreach ( $submenu[ self::SLUG ] as $key => $item ) {
			// Slot 2 holds the menu slug; the auto-added parent row uses 'volade-breadcrumbs'.
			$slug = isset( $item[2] ) ? (string) $item[2] : '';

			if ( ! isset( self::SCREENS[ $slug ] ) ) {
				continue;
			}

			$submenu[ self::SLUG ][ $key ][4] = 'volade-subicon ' . self::SCREENS[ $slug ]['icon'];
		}
	}

	/**
	 * Plugin action links.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function plugin_action_links( $links ) {
		$settings_link = '<a href="' . esc_url( admin_url( 'admin.php?page=volade-breadcrumbs-settings' ) ) . '">' . esc_html__( 'Settings', 'volade-breadcrumbs' ) . '</a>';
		array_unshift( $links, $settings_link );

		$upgrade_url  = get_option( 'volade_upgrade_url', 'https://volade.com/' );
		$upgrade_link = '<a href="' . esc_url( $upgrade_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Upgrade to Pro', 'volade-breadcrumbs' ) . '</a>';
		$links[]      = $upgrade_link;

		return $links;
	}

	/**
	 * Plugin row meta (discrete links under the plugin name).
	 *
	 * @param array  $links Existing links.
	 * @param string $file  Plugin file.
	 * @return array
	 */
	public function plugin_row_meta( $links, $file ) {
		if ( plugin_basename( VOLADE_BREADCRUMBS_PLUGIN_FILE ) !== $file ) {
			return $links;
		}

		$upgrade_url      = get_option( 'volade_upgrade_url', 'https://volade.com/' );
		$row_meta         = array();
		$row_meta['docs'] = '<a href="' . esc_url( Volade_Breadcrumbs_I18n::site_url( 'faq' ) ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Documentation', 'volade-breadcrumbs' ) . '</a>';
		$row_meta['pro']  = '<a href="' . esc_url( $upgrade_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Upgrade to Pro', 'volade-breadcrumbs' ) . '</a>';
		$row_meta['reviews'] = '<a href="https://wordpress.org/support/plugin/volade-breadcrumbs/reviews/#new-post" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Leave a review', 'volade-breadcrumbs' ) . '</a>';

		return array_merge( $links, $row_meta );
	}

	/**
	 * Meta box: hide the trail on one item.
	 *
	 * Landing pages, thank-you pages and funnels usually want no navigation
	 * above their content. Instead of asking for a template edit, that
	 * decision travels with the item itself, which is also how every
	 * competing plugin handles it.
	 *
	 * @param string $post_type Post type slug.
	 */
	public function add_hide_metabox( $post_type ) {
		if ( ! in_array( $post_type, Volade_Breadcrumbs_Trail::post_types(), true ) ) {
			return;
		}

		add_meta_box(
			'volade-bc-hide',
			__( 'Breadcrumbs', 'volade-breadcrumbs' ),
			array( $this, 'render_hide_metabox' ),
			$post_type,
			'side',
			'default'
		);
	}

	/**
	 * Render the meta box.
	 *
	 * @param WP_Post $post Post being edited.
	 */
	public function render_hide_metabox( $post ) {
		wp_nonce_field( 'volade-bc-hide', 'volade_bc_hide_nonce' );

		echo '<label class="volade-bc-hide">';
		echo '<input type="checkbox" name="volade_bc_hide" value="1" ' . checked( Volade_Breadcrumbs_Trail::is_hidden( $post->ID ), true, false ) . ' />';
		echo '<span>' . esc_html__( 'Hide the breadcrumb trail on this page', 'volade-breadcrumbs' ) . '</span>';
		echo '</label>';
		echo '<p class="description">' . esc_html__( 'Applies to the trail placed automatically above the content. A trail added with the block or the shortcode always shows.', 'volade-breadcrumbs' ) . '</p>';
	}

	/**
	 * Save the meta box.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 */
	public function save_hide_metabox( $post_id, $post ) {
		if ( ! isset( $_POST['volade_bc_hide_nonce'] ) ) {
			return;
		}

		$nonce = sanitize_text_field( wp_unslash( $_POST['volade_bc_hide_nonce'] ) );

		if ( ! wp_verify_nonce( $nonce, 'volade-bc-hide' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! $post instanceof WP_Post || 'revision' === $post->post_type ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// The nonce is printed by the box itself, so reaching this line means
		// the box was on this screen: a missing checkbox is a box the editor
		// deliberately left unchecked, and the flag has to come off again.
		if ( isset( $_POST['volade_bc_hide'] )
			&& '1' === (string) sanitize_text_field( wp_unslash( $_POST['volade_bc_hide'] ) ) ) {
			update_post_meta( $post_id, '_volade_bc_hide', '1' );
		} else {
			delete_post_meta( $post_id, '_volade_bc_hide' );
		}
	}

	/**
	 * Register settings, sections and fields.
	 */
	public function register_settings() {
		// API settings.
		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_api_base_url',
			array(
				'sanitize_callback' => 'esc_url_raw',
				'default'           => Volade_Breadcrumbs_API::DEFAULT_API_BASE,
			)
		);

		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_premium_endpoint',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => 'premium/check',
			)
		);

		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_api_key',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '',
			)
		);

		// Breadcrumb settings (this plugin only).
		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_bc_enabled',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '1',
			)
		);

		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_bc_post_types',
			array(
				'sanitize_callback' => array( 'Volade_Breadcrumbs_Trail', 'sanitize_post_types' ),
				'default'           => '',
			)
		);

		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_bc_show_home',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '1',
			)
		);

		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_bc_home',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '',
			)
		);

		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_bc_hide_home',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '1',
			)
		);

		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_bc_separator',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '/',
			)
		);

		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_bc_style',
			array(
				'sanitize_callback' => array( 'Volade_Breadcrumbs_Trail', 'sanitize_style' ),
				'default'           => 'default',
			)
		);

		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_bc_depth',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);

		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_bc_schema',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '1',
			)
		);

		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_bc_hide_title',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '0',
			)
		);

		register_setting(
			'volade-breadcrumbs_settings_api',
			'volade_bc_woo',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '1',
			)
		);

		// License settings.
		register_setting(
			'volade-breadcrumbs_settings_license',
			'volade_license_key',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '',
			)
		);

		register_setting(
			'volade-breadcrumbs_settings_license',
			'volade_upgrade_url',
			array(
				'sanitize_callback' => 'esc_url_raw',
				'default'           => 'https://volade.com/',
			)
		);

		// Language setting (handled by Volade_Breadcrumbs_I18n).
		Volade_Breadcrumbs_I18n::register_setting();

		// Sections. The breadcrumb section comes first: it is what this
		// plugin is for, the API connection below it is shared suite plumbing.
		add_settings_section(
			'volade_bc_section',
			esc_html__( 'Breadcrumbs', 'volade-breadcrumbs' ),
			array( $this, 'render_bc_section' ),
			'volade-breadcrumbs-settings-api'
		);

		add_settings_section(
			'volade_api_section',
			esc_html__( 'API Connection', 'volade-breadcrumbs' ),
			array( $this, 'render_api_section' ),
			'volade-breadcrumbs-settings-api'
		);

		add_settings_section(
			'volade_license_section',
			esc_html__( 'License & Upgrade', 'volade-breadcrumbs' ),
			array( $this, 'render_license_section' ),
			'volade-breadcrumbs-settings-license'
		);

		add_settings_section(
			'volade_language_section',
			esc_html__( 'Interface language', 'volade-breadcrumbs' ),
			array( $this, 'render_language_section' ),
			'volade-breadcrumbs-settings-language'
		);

		// API fields.
		add_settings_field(
			'volade_api_base_url',
			esc_html__( 'API Base URL', 'volade-breadcrumbs' ),
			array( $this, 'field_api_base_url' ),
			'volade-breadcrumbs-settings-api',
			'volade_api_section'
		);

		add_settings_field(
			'volade_premium_endpoint',
			esc_html__( 'Premium Check Endpoint', 'volade-breadcrumbs' ),
			array( $this, 'field_premium_endpoint' ),
			'volade-breadcrumbs-settings-api',
			'volade_api_section'
		);

		add_settings_field(
			'volade_api_key',
			esc_html__( 'API Key (Bearer)', 'volade-breadcrumbs' ),
			array( $this, 'field_api_key' ),
			'volade-breadcrumbs-settings-api',
			'volade_api_section'
		);

		// Breadcrumb fields.
		add_settings_field(
			'volade_bc_enabled',
			esc_html__( 'Show breadcrumbs', 'volade-breadcrumbs' ),
			array( $this, 'field_bc_enabled' ),
			'volade-breadcrumbs-settings-api',
			'volade_bc_section'
		);

		add_settings_field(
			'volade_bc_post_types',
			esc_html__( 'Post types', 'volade-breadcrumbs' ),
			array( $this, 'field_bc_post_types' ),
			'volade-breadcrumbs-settings-api',
			'volade_bc_section'
		);

		add_settings_field(
			'volade_bc_show_home',
			esc_html__( 'Show the homepage item', 'volade-breadcrumbs' ),
			array( $this, 'field_bc_show_home' ),
			'volade-breadcrumbs-settings-api',
			'volade_bc_section'
		);

		add_settings_field(
			'volade_bc_home',
			esc_html__( 'Home label', 'volade-breadcrumbs' ),
			array( $this, 'field_bc_home' ),
			'volade-breadcrumbs-settings-api',
			'volade_bc_section'
		);

		add_settings_field(
			'volade_bc_hide_home',
			esc_html__( 'Hide on the homepage', 'volade-breadcrumbs' ),
			array( $this, 'field_bc_hide_home' ),
			'volade-breadcrumbs-settings-api',
			'volade_bc_section'
		);

		add_settings_field(
			'volade_bc_separator',
			esc_html__( 'Separator', 'volade-breadcrumbs' ),
			array( $this, 'field_bc_separator' ),
			'volade-breadcrumbs-settings-api',
			'volade_bc_section'
		);

		add_settings_field(
			'volade_bc_style',
			esc_html__( 'Style', 'volade-breadcrumbs' ),
			array( $this, 'field_bc_style' ),
			'volade-breadcrumbs-settings-api',
			'volade_bc_section'
		);

		add_settings_field(
			'volade_bc_depth',
			esc_html__( 'Maximum depth', 'volade-breadcrumbs' ),
			array( $this, 'field_bc_depth' ),
			'volade-breadcrumbs-settings-api',
			'volade_bc_section'
		);

		add_settings_field(
			'volade_bc_schema',
			esc_html__( 'Structured data (JSON-LD)', 'volade-breadcrumbs' ),
			array( $this, 'field_bc_schema' ),
			'volade-breadcrumbs-settings-api',
			'volade_bc_section'
		);

		add_settings_field(
			'volade_bc_hide_title',
			esc_html__( 'Hide the current page title', 'volade-breadcrumbs' ),
			array( $this, 'field_bc_hide_title' ),
			'volade-breadcrumbs-settings-api',
			'volade_bc_section'
		);

		add_settings_field(
			'volade_bc_woo',
			esc_html__( 'Replace the WooCommerce breadcrumb', 'volade-breadcrumbs' ),
			array( $this, 'field_bc_woo' ),
			'volade-breadcrumbs-settings-api',
			'volade_bc_section'
		);

		// License fields.
		add_settings_field(
			'volade_license_key',
			esc_html__( 'License Key', 'volade-breadcrumbs' ),
			array( $this, 'field_license_key' ),
			'volade-breadcrumbs-settings-license',
			'volade_license_section'
		);

		add_settings_field(
			'volade_upgrade_url',
			esc_html__( 'Upgrade URL', 'volade-breadcrumbs' ),
			array( $this, 'field_upgrade_url' ),
			'volade-breadcrumbs-settings-license',
			'volade_license_section'
		);

		// Language field.
		add_settings_field(
			Volade_Breadcrumbs_I18n::OPTION,
			esc_html__( 'Language', 'volade-breadcrumbs' ),
			array( 'Volade_Breadcrumbs_I18n', 'render_field' ),
			'volade-breadcrumbs-settings-language',
			'volade_language_section'
		);
	}

	/**
	 * Cache key for a plugin asset.
	 *
	 * VOLADE_BREADCRUMBS_VERSION alone was a broken key: every re-upload of 1.0.0 kept
	 * producing the same `admin.css?ver=1.0.0` URL, so browsers went on
	 * serving the previously downloaded stylesheet and layout edits never
	 * became visible. Appending the file mtime makes the query string change
	 * exactly when the bytes change.
	 *
	 * @param string $relative Path relative to the plugin root.
	 * @return string
	 */
	public static function asset_version( $relative ) {
		$path = VOLADE_BREADCRUMBS_PLUGIN_DIR . $relative;
		$mtime = ( file_exists( $path ) ) ? filemtime( $path ) : 0;

		return VOLADE_BREADCRUMBS_VERSION . '-' . $mtime;
	}

	/**
	 * Enqueue assets on Volade screens only.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_assets( $hook ) {
		// Menu icon must be available on every admin screen.
		wp_enqueue_style(
			'volade-breadcrumbs-menu',
			VOLADE_BREADCRUMBS_PLUGIN_URL . 'assets/css/menu.css',
			array(),
			self::asset_version( 'assets/css/menu.css' )
		);

		if ( false === strpos( $hook, self::SLUG ) ) {
			return;
		}

		wp_enqueue_style(
			'volade-breadcrumbs-admin',
			VOLADE_BREADCRUMBS_PLUGIN_URL . 'assets/css/admin.css',
			array( 'volade-breadcrumbs-menu' ),
			self::asset_version( 'assets/css/admin.css' )
		);

		/*
		 * The style cards on the settings screen are the real trail markup
		 * wrapped around a radio, so they also need the stylesheet the
		 * visitor gets - otherwise a preview would show the colours but not
		 * the pills or the numbered counters it promises.
		 */
		wp_enqueue_style(
			'volade-breadcrumbs-preview',
			VOLADE_BREADCRUMBS_PLUGIN_URL . 'assets/css/breadcrumbs.css',
			array(),
			self::asset_version( 'assets/css/breadcrumbs.css' )
		);

		wp_enqueue_script(
			'volade-breadcrumbs-admin',
			VOLADE_BREADCRUMBS_PLUGIN_URL . 'assets/js/admin.js',
			array(),
			self::asset_version( 'assets/js/admin.js' ),
			true
		);
	}

	/**
	 * Section renderers.
	 */
	public function render_api_section() {
		echo '<p>' . esc_html__( 'Configure connection to Volade API. These values are used to verify Premium entitlements.', 'volade-breadcrumbs' ) . '</p>';
	}

	public function render_bc_section() {
		echo '<p>' . esc_html__( 'Choose where the trail appears and how it looks.', 'volade-breadcrumbs' ) . '</p>';
	}

	/**
	 * Output one of the on/off settings.
	 *
	 * A hidden "0" precedes the checkbox on purpose: WordPress only writes the
	 * options it actually receives, so without it an unchecked box would keep
	 * its previous value and the setting could never be turned off again.
	 *
	 * @param string $option Option name.
	 */
	private function bc_checkbox( $option ) {
		$defaults = Volade_Breadcrumbs_Tools::defaults();
		$value    = get_option( $option, isset( $defaults[ $option ] ) ? $defaults[ $option ] : '0' );

		echo '<input type="hidden" name="' . esc_attr( $option ) . '" value="0" />';
		echo '<input type="checkbox" name="' . esc_attr( $option ) . '" value="1" ' . checked( '1', $value, false ) . ' />';
	}

	public function field_bc_enabled() {
		$this->bc_checkbox( 'volade_bc_enabled' );
		echo '<p class="description">' . esc_html__( 'Display the trail above the content of posts, pages and custom post types.', 'volade-breadcrumbs' ) . '</p>';
	}

	public function field_bc_post_types() {
		$value = get_option( 'volade_bc_post_types', '' );
		echo '<input type="text" name="volade_bc_post_types" class="regular-text volade-input" value="' . esc_attr( $value ) . '" placeholder="post, page, product" />';
		echo '<p class="description">' . esc_html__( 'Comma-separated list of post type slugs. Leave empty for every public type.', 'volade-breadcrumbs' ) . '</p>';
	}

	public function field_bc_show_home() {
		$this->bc_checkbox( 'volade_bc_show_home' );
	}

	public function field_bc_home() {
		$value = get_option( 'volade_bc_home', '' );
		echo '<input type="text" name="volade_bc_home" class="regular-text volade-input" value="' . esc_attr( $value ) . '" />';
		echo '<p class="description">' . esc_html__( 'Text of the first item, which links back to the homepage.', 'volade-breadcrumbs' ) . '</p>';
	}

	public function field_bc_hide_home() {
		$this->bc_checkbox( 'volade_bc_hide_home' );
	}

	public function field_bc_separator() {
		$value = get_option( 'volade_bc_separator', '/' );
		echo '<input type="text" name="volade_bc_separator" class="small-text volade-input" value="' . esc_attr( $value ) . '" placeholder="/" />';
		echo '<p class="description">' . esc_html__( 'Printed between two items of the trail.', 'volade-breadcrumbs' ) . '</p>';
	}

	public function field_bc_style() {
		$value   = get_option( 'volade_bc_style', 'default' );
		$options = Volade_Breadcrumbs_Trail::styles();

		// The stored value can only be one of the presets the sanitizer
		// allows; a stray value simply falls back to the first one, so one
		// radio is always checked and the option is always submitted.
		if ( ! array_key_exists( $value, $options ) ) {
			$value = 'default';
		}

		echo '<div class="volade-bc-styles">';

		foreach ( $options as $slug => $label ) {
			echo '<label class="volade-bc-style">';
			echo '<input type="radio" name="volade_bc_style" value="' . esc_attr( $slug ) . '" ' . checked( $value, $slug, false ) . ' />';
			echo '<span class="volade-bc-style-body">';
			echo '<span class="volade-bc-style-name">' . esc_html( $label ) . '</span>';
			echo $this->style_sample( $slug ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- style_sample() escapes every part it builds.
			echo '</span>';
			echo '</label>';
		}

		echo '</div>';
		echo '<p class="description">' . esc_html__( 'Click a preview to pick it. The trail above your posts uses the one you choose.', 'volade-breadcrumbs' ) . '</p>';
	}

	/**
	 * One trail rendered with the shipped stylesheet, as a settings preview.
	 *
	 * Every level is drawn as a span rather than a link: the preview lives on
	 * a form, and a link there would either navigate away from the settings
	 * or have to be switched off by script.
	 *
	 * @param string $slug Style preset.
	 * @return string
	 */
	private function style_sample( $slug ) {
		$separator = trim( (string) get_option( 'volade_bc_separator', '/' ) );
		$separator = ( '' === $separator ) ? '/' : $separator;

		$steps = array(
			array( __( 'Home', 'volade-breadcrumbs' ), false ),
			array( __( 'Category', 'volade-breadcrumbs' ), false ),
			array( __( 'Sample page', 'volade-breadcrumbs' ), true ),
		);

		$markup = '';
		$index  = 1;

		foreach ( $steps as $step ) {
			$markup .= '<span class="volade-bc-item">';
			$markup .= $step[1]
				? '<span class="volade-bc-current">' . esc_html( $step[0] ) . '</span>'
				: '<span class="volade-bc-link">' . esc_html( $step[0] ) . '</span>';

			if ( $index < count( $steps ) ) {
				$markup .= '<span class="volade-bc-sep" aria-hidden="true">' . esc_html( $separator ) . '</span>';
			}

			$markup .= '</span>';
			$index++;
		}

		// The preset name is chosen outside the attribute on purpose: the
		// class-coverage audit reads the variant literals out of render(),
		// and a half written "volade-bc--" here would look like a class that
		// no stylesheet provides.
		$variant = ( 'minimal' === $slug )
			? 'volade-bc volade-bc--minimal'
			: ( ( 'pill' === $slug )
				? 'volade-bc volade-bc--pill'
				: ( ( 'numbered' === $slug )
					? 'volade-bc volade-bc--numbered'
					: 'volade-bc volade-bc--default' ) );

		return '<span class="' . esc_attr( $variant ) . '">'
			. '<span class="volade-bc-list">' . $markup . '</span>'
			. '</span>';
	}

	public function field_bc_depth() {
		$value = get_option( 'volade_bc_depth', '0' );
		echo '<input type="number" name="volade_bc_depth" class="small-text" min="0" max="9" value="' . esc_attr( $value ) . '" />';
		echo '<p class="description">' . esc_html__( 'Number of levels to print. Use 0 for no limit.', 'volade-breadcrumbs' ) . '</p>';
	}

	public function field_bc_schema() {
		$this->bc_checkbox( 'volade_bc_schema' );
		echo '<p class="description">' . esc_html__( 'Print a BreadcrumbList block with the trail so search engines understand it.', 'volade-breadcrumbs' ) . '</p>';
	}

	public function field_bc_hide_title() {
		$this->bc_checkbox( 'volade_bc_hide_title' );
		echo '<p class="description">' . esc_html__( 'Leaves only the levels above the current page on screen; search engines still receive the full path.', 'volade-breadcrumbs' ) . '</p>';
	}

	public function field_bc_woo() {
		$this->bc_checkbox( 'volade_bc_woo' );
		echo '<p class="description">' . esc_html__( 'Prints this trail from Home to Shop, category and product instead of the one WooCommerce ships.', 'volade-breadcrumbs' ) . '</p>';

		if ( ! class_exists( 'WooCommerce' ) ) {
			echo '<p class="description volade-note">' . esc_html__( 'WooCommerce is not installed on this site, so this setting has no effect yet.', 'volade-breadcrumbs' ) . '</p>';
		}
	}

	public function render_license_section() {
		echo '<p>' . esc_html__( 'License validation is handled server-side via the Volade API. No payment processing happens inside this plugin.', 'volade-breadcrumbs' ) . '</p>';
	}

	public function render_language_section() {
		echo '<p>' . esc_html__( 'Choose the language of the Volade screens. 17 languages available, each with its flag.', 'volade-breadcrumbs' ) . '</p>';
	}

	/**
	 * Field renderers.
	 */
	public function field_api_base_url() {
		$value = get_option( 'volade_api_base_url', Volade_Breadcrumbs_API::DEFAULT_API_BASE );
		echo '<input type="url" name="volade_api_base_url" class="regular-text volade-input" value="' . esc_attr( $value ) . '" placeholder="https://api.volade.com/v1" />';
		echo '<p class="description">' . esc_html__( 'Base URL of Volade API (no trailing slash).', 'volade-breadcrumbs' ) . '</p>';
	}

	public function field_premium_endpoint() {
		$value = get_option( 'volade_premium_endpoint', 'premium/check' );
		echo '<input type="text" name="volade_premium_endpoint" class="regular-text volade-input" value="' . esc_attr( $value ) . '" placeholder="premium/check" />';
		echo '<p class="description">' . esc_html__( 'Relative endpoint path for premium entitlement check.', 'volade-breadcrumbs' ) . '</p>';
	}

	public function field_api_key() {
		$value = get_option( 'volade_api_key', '' );
		echo '<input type="password" name="volade_api_key" class="regular-text volade-input" value="' . esc_attr( $value ) . '" autocomplete="off" />';
		echo '<p class="description">' . esc_html__( 'Optional Bearer token if the API requires authentication.', 'volade-breadcrumbs' ) . '</p>';
	}

	public function field_license_key() {
		$value = get_option( 'volade_license_key', '' );
		echo '<input type="text" name="volade_license_key" class="regular-text volade-input" value="' . esc_attr( $value ) . '" />';
		echo '<p class="description">' . esc_html__( 'Site/license key used for entitlement verification (if applicable).', 'volade-breadcrumbs' ) . '</p>';
	}

	public function field_upgrade_url() {
		$value = get_option( 'volade_upgrade_url', 'https://volade.com/' );
		echo '<input type="url" name="volade_upgrade_url" class="regular-text volade-input" value="' . esc_attr( $value ) . '" />';
		echo '<p class="description">' . esc_html__( 'Off-site upgrade URL for Pro features (WordPress.org-compliant).', 'volade-breadcrumbs' ) . '</p>';
	}

	/**
	 * Translated label of a registered screen.
	 *
	 * @param string $slug Menu slug.
	 * @return string
	 */
	public static function screen_label( $slug ) {
		switch ( $slug ) {
			case 'volade-breadcrumbs-settings':
				return __( 'Settings', 'volade-breadcrumbs' );
			case 'volade-breadcrumbs-license':
				return __( 'License', 'volade-breadcrumbs' );
			case 'volade-breadcrumbs-language':
				return __( 'Language', 'volade-breadcrumbs' );
			case 'volade-breadcrumbs-tools':
				return __( 'Tools', 'volade-breadcrumbs' );
			case 'volade-breadcrumbs-about':
				return __( 'About', 'volade-breadcrumbs' );
			default:
				return __( 'Volade Breadcrumbs', 'volade-breadcrumbs' );
		}
	}

	/**
	 * Current view id based on the requested page slug.
	 *
	 * @return string
	 */
	private function get_view() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : self::SLUG; // phpcs:ignore WordPress.Security.NonceVerification -- screen slug only, matched against SCREENS below.

		return isset( self::SCREENS[ $page ] ) ? self::SCREENS[ $page ]['view'] : 'overview';
	}

	/**
	 * Installed version plus, when core knows of one, the available update.
	 *
	 * Reads WordPress.org's own update transient exclusively. Guideline 8
	 * forbids "serving updates ... from servers other than WordPress.org's",
	 * so this never asks volade.com whether a newer build exists - core
	 * already learns that from the plugin directory API, and the button only
	 * links to core's own update.php screen.
	 *
	 * @return array installed, latest, available, url.
	 */
	private static function update_status() {
		$status = array(
			'installed' => VOLADE_BREADCRUMBS_VERSION,
			'latest'    => VOLADE_BREADCRUMBS_VERSION,
			'available' => false,
			'url'       => '',
		);

		$transient = get_site_transient( 'update_plugins' );

		if ( ! $transient || ! isset( $transient->response[ VOLADE_BREADCRUMBS_PLUGIN_BASE ] ) ) {
			return $status;
		}

		$response = $transient->response[ VOLADE_BREADCRUMBS_PLUGIN_BASE ];
		$latest   = isset( $response->new_version ) ? (string) $response->new_version : VOLADE_BREADCRUMBS_VERSION;

		// Core only lists a plugin in ->response when an update exists, but
		// guard anyway so a malformed payload can never show a bogus button.
		if ( version_compare( $latest, VOLADE_BREADCRUMBS_VERSION, '<=' ) ) {
			return $status;
		}

		$status['latest']    = $latest;
		$status['available'] = true;
		$status['url']       = wp_nonce_url(
			self_admin_url( 'update.php?action=upgrade-plugin&plugin=' . VOLADE_BREADCRUMBS_PLUGIN_BASE ),
			'upgrade-plugin_' . VOLADE_BREADCRUMBS_PLUGIN_BASE
		);

		return $status;
	}

	/**
	 * Render the requested Volade screen.
	 */
	public function render_page() {
		if ( ! current_user_can( self::capability() ) ) {
			return;
		}

		$view   = $this->get_view();
		$update = self::update_status();

		/**
		 * Fires before a Volade screen is printed, inside the page wrapper.
		 *
		 * @param string $view One of overview, settings, license, language, tools, about.
		 */
		do_action( 'volade_before_render', $view );
		?>
		<div class="wrap volade-wrap<?php echo Volade_Breadcrumbs_I18n::is_rtl() ? ' volade-rtl' : ''; ?>"<?php echo Volade_Breadcrumbs_I18n::is_rtl() ? ' dir="rtl"' : ''; ?>>
			<?php settings_errors(); ?>

			<div class="volade-hero">
				<div class="volade-hero-brand">
					<img class="volade-hero-logo" src="<?php echo esc_url( VOLADE_BREADCRUMBS_PLUGIN_URL . 'logo.webp' ); ?>" alt="" width="52" height="52" />
					<div class="volade-hero-text">
						<h1 class="volade-title">
							<?php esc_html_e( 'Volade Breadcrumbs', 'volade-breadcrumbs' ); ?>
							<span class="volade-version"><?php echo esc_html( VOLADE_BREADCRUMBS_VERSION ); ?></span>
							<?php if ( $update['available'] ) : ?>
								<a class="volade-update" href="<?php echo esc_url( $update['url'] ); ?>">
									<?php
								/* translators: %s: latest version number available for this update. */
								echo esc_html( sprintf( __( 'Update to %s', 'volade-breadcrumbs' ), $update['latest'] ) );
								?>
								</a>
							<?php else : ?>
								<span class="volade-version volade-version-ok"><?php esc_html_e( 'Version up to date', 'volade-breadcrumbs' ); ?></span>
							<?php endif; ?>
						</h1>
						<p class="volade-subtitle"><?php esc_html_e( 'Add a breadcrumb trail to your content and a BreadcrumbList schema for search engines.', 'volade-breadcrumbs' ); ?></p>
					</div>
				</div>

				<div class="volade-hero-meta">
					<?php if ( get_transient( Volade_Breadcrumbs_Premium::CACHE_KEY ) ) : ?>
						<span class="volade-badge volade-badge-success"><?php esc_html_e( 'Premium active on this site', 'volade-breadcrumbs' ); ?></span>
					<?php else : ?>
						<span class="volade-badge volade-badge-neutral"><?php esc_html_e( 'Not premium', 'volade-breadcrumbs' ); ?></span>
					<?php endif; ?>

					<a href="<?php echo esc_url( Volade_Breadcrumbs_Premium::get_upgrade_url() ); ?>" target="_blank" rel="noopener noreferrer" class="button volade-btn-primary">
						<?php esc_html_e( 'Discover Premium', 'volade-breadcrumbs' ); ?>
					</a>
				</div>
			</div>

			<?php
			switch ( $view ) {
				case 'settings':
					$this->view_settings();
					break;
				case 'license':
					$this->view_license();
					break;
				case 'language':
					$this->view_language();
					break;
				case 'tools':
					$this->view_tools();
					break;
				case 'about':
					$this->view_about();
					break;
				default:
					$this->view_overview();
					break;
			}
			?>

			<?php
			/**
			 * Fires after the screen body, still inside the page wrapper.
			 *
			 * @param string $view Same view id passed to volade_before_render.
			 */
			do_action( 'volade_after_render', $view );
			?>
		</div>
		<?php
	}

	/**
	 * Overview screen.
	 */
	private function view_overview() {
		$is_premium = (bool) get_transient( Volade_Breadcrumbs_Premium::CACHE_KEY );

		$tiles = array(
			'volade-breadcrumbs-settings' => array(
				'icon' => 'dashicons-admin-settings',
				'text' => __( 'Configure the API connection and the premium check endpoint.', 'volade-breadcrumbs' ),
			),
			'volade-breadcrumbs-license'  => array(
				'icon' => 'dashicons-shield',
				'text' => __( 'Manage the license key and the off-site upgrade link.', 'volade-breadcrumbs' ),
			),
			'volade-breadcrumbs-language' => array(
				'icon' => 'dashicons-translation',
				'text' => __( 'Pick the interface language from 17 options with flags.', 'volade-breadcrumbs' ),
			),
			'volade-breadcrumbs-tools'    => array(
				'icon' => 'dashicons-admin-tools',
				'text' => __( 'Test the premium check and manage the result cache.', 'volade-breadcrumbs' ),
			),
		);
		?>
		<div class="volade-grid">
			<div class="volade-card volade-card-status">
				<h2>
					<span class="volade-card-icon" aria-hidden="true"><span class="dashicons dashicons-star-filled"></span></span>
					<?php esc_html_e( 'Premium Status', 'volade-breadcrumbs' ); ?>
				</h2>
				<p>
					<?php if ( $is_premium ) : ?>
						<span class="volade-badge volade-badge-success"><?php esc_html_e( 'Premium active on this site', 'volade-breadcrumbs' ); ?></span>
					<?php else : ?>
						<span class="volade-badge volade-badge-neutral"><?php esc_html_e( 'Not premium', 'volade-breadcrumbs' ); ?></span>
					<?php endif; ?>
				</p>
				<p class="description"><?php esc_html_e( 'Test the connection to verify premium entitlement. The result is cached afterwards.', 'volade-breadcrumbs' ); ?></p>
				<p>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=volade-breadcrumbs-tools' ) ); ?>" class="button volade-btn-secondary">
						<?php esc_html_e( 'Test Premium Status', 'volade-breadcrumbs' ); ?>
					</a>
				</p>
			</div>

			<div class="volade-card">
				<h2>
					<span class="volade-card-icon" aria-hidden="true"><span class="dashicons dashicons-grid-view"></span></span>
					<?php esc_html_e( 'Quick access', 'volade-breadcrumbs' ); ?>
				</h2>
				<ul class="volade-tiles">
					<?php foreach ( $tiles as $slug => $tile ) : ?>
						<li>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . $slug ) ); ?>">
								<span class="volade-tile-icon" aria-hidden="true"><span class="dashicons <?php echo esc_attr( $tile['icon'] ); ?>"></span></span>
								<span class="volade-tile-body">
									<span class="volade-tile-title"><?php echo esc_html( self::screen_label( $slug ) ); ?></span>
									<span class="volade-tile-text"><?php echo esc_html( $tile['text'] ); ?></span>
								</span>
								<span class="dashicons dashicons-arrow-right-alt2 volade-tile-arrow" aria-hidden="true"></span>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>

			<div class="volade-card volade-card-muted">
				<h3>
					<span class="volade-card-icon" aria-hidden="true"><span class="dashicons dashicons-awards"></span></span>
					<?php esc_html_e( 'Getting started', 'volade-breadcrumbs' ); ?>
				</h3>
				<?php $this->render_setup_progress(); ?>
			</div>
		</div>

		<?php $this->render_premium_compare(); ?>

		<?php $this->render_external_services(); ?>
		<?php
	}

	/**
	 * "Getting started" checklist and its progress bar.
	 *
	 * This is the local, consent-free kind of gamification: every step is read
	 * from state already sitting in the database, so rendering it sends nothing
	 * anywhere and gates nothing. Nothing is locked behind the count - it is a
	 * hint about what is left to configure, not a trial.
	 */
	private function render_setup_progress() {
		$steps = array(
			array(
				'done'  => true,
				'label' => __( 'Activate the plugin', 'volade-breadcrumbs' ),
				'url'   => '',
			),
			array(
				'done'  => (bool) get_option( Volade_Breadcrumbs_Tools::SETUP_OPTION ),
				'label' => __( 'Configure the API connection', 'volade-breadcrumbs' ),
				'url'   => admin_url( 'admin.php?page=volade-breadcrumbs-settings' ),
			),
			array(
				'done'  => ( null !== Volade_Breadcrumbs_Premium::get_last_test() ),
				'label' => __( 'Test Premium Status', 'volade-breadcrumbs' ),
				'url'   => admin_url( 'admin.php?page=volade-breadcrumbs-tools' ),
			),
		);

		$total = count( $steps );
		$done  = 0;

		foreach ( $steps as $step ) {
			if ( $step['done'] ) {
				$done++;
			}
		}

		$percent = (int) round( ( $done / $total ) * 100 );
		?>
		<p class="volade-setup-progress">
			<span class="volade-setup-bar" aria-hidden="true">
				<span class="volade-setup-fill" style="width:<?php echo esc_attr( $percent . '%' ); ?>"></span>
			</span>
			<?php
			/* translators: 1: number of setup steps already completed. 2: total number of setup steps. */
			echo esc_html( sprintf( __( '%1$d of %2$d steps completed', 'volade-breadcrumbs' ), $done, $total ) );
			?>
		</p>

		<ul class="volade-checklist">
			<?php foreach ( $steps as $step ) : ?>
				<li class="<?php echo $step['done'] ? 'volade-setup-done' : 'volade-setup-todo'; ?>">
					<span class="dashicons <?php echo $step['done'] ? 'dashicons-yes-alt' : 'dashicons-clock'; ?>" aria-hidden="true"></span>
					<?php if ( '' === $step['url'] ) : ?>
						<?php echo esc_html( $step['label'] ); ?>
					<?php else : ?>
						<a href="<?php echo esc_url( $step['url'] ); ?>"><?php echo esc_html( $step['label'] ); ?></a>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
	}

	/**
	 * Settings screen.
	 */
	private function view_settings() {
		?>
		<div class="volade-card">
			<form method="post" action="options.php">
				<?php
				settings_fields( 'volade-breadcrumbs_settings_api' );
				do_settings_sections( 'volade-breadcrumbs-settings-api' );
				submit_button();
				?>
			</form>
		</div>

		<?php $this->render_premium_compare(); ?>
		<?php
	}

	/**
	 * License screen.
	 */
	private function view_license() {
		?>
		<div class="volade-card">
			<form method="post" action="options.php">
				<?php
				settings_fields( 'volade-breadcrumbs_settings_license' );
				do_settings_sections( 'volade-breadcrumbs-settings-license' );
				submit_button();
				?>
			</form>
		</div>

		<div class="volade-card volade-card-muted">
			<h3>
				<span class="volade-card-icon" aria-hidden="true"><span class="dashicons dashicons-shield"></span></span>
				<?php esc_html_e( 'About License Validation', 'volade-breadcrumbs' ); ?>
			</h3>
			<p><?php esc_html_e( 'Premium entitlements are validated server-side through api.volade.com. This keeps the plugin lightweight, secure, and fully compliant with WordPress.org guidelines.', 'volade-breadcrumbs' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Language screen.
	 */
	private function view_language() {
		?>
		<div class="volade-card">
			<form method="post" action="options.php">
				<?php
				settings_fields( 'volade-breadcrumbs_settings_language' );
				do_settings_sections( 'volade-breadcrumbs-settings-language' );
				submit_button( __( 'Save Language', 'volade-breadcrumbs' ) );
				?>
			</form>
		</div>

		<div class="volade-card volade-card-muted">
			<h3>
				<span class="volade-card-icon" aria-hidden="true"><span class="dashicons dashicons-translation"></span></span>
				<?php esc_html_e( 'About languages', 'volade-breadcrumbs' ); ?>
			</h3>
			<p><?php esc_html_e( 'The Volade interface is set up for 17 languages; translations are delivered by WordPress.org language packs. If your WordPress site language is one of them, the plugin follows it automatically.', 'volade-breadcrumbs' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Tools screen.
	 *
	 * The test runs in Volade_Breadcrumbs_Premium::test_premium() (admin_post handler) and
	 * stores its outcome in a transient; this view only ever reads, so the page
	 * never blocks on a network request while rendering.
	 */
	private function view_tools() {
		$last_test  = Volade_Breadcrumbs_Premium::get_last_test();
		$notice     = Volade_Breadcrumbs_Tools::current_notice();
		$info       = Volade_Breadcrumbs_Tools::system_info();
		$export_url = wp_nonce_url(
			admin_url( 'admin-post.php?action=volade-breadcrumbs_export_settings' ),
			'volade-breadcrumbs_export_settings'
		);
		?>
		<?php if ( null !== $notice && 'error' === $notice['type'] ) : ?>
			<p class="volade-notice volade-notice-error"><?php echo esc_html( $notice['text'] ); ?></p>
		<?php elseif ( null !== $notice ) : ?>
			<p class="volade-notice volade-notice-success"><?php echo esc_html( $notice['text'] ); ?></p>
		<?php endif; ?>

		<div class="volade-card">
			<h2>
				<span class="volade-card-icon" aria-hidden="true"><span class="dashicons dashicons-admin-tools"></span></span>
				<?php esc_html_e( 'Premium Status', 'volade-breadcrumbs' ); ?>
			</h2>

			<?php if ( null !== $last_test ) : ?>
				<p>
					<?php if ( $last_test['premium'] ) : ?>
						<span class="volade-badge volade-badge-success"><?php esc_html_e( 'Premium active', 'volade-breadcrumbs' ); ?></span>
					<?php else : ?>
						<span class="volade-badge volade-badge-neutral"><?php esc_html_e( 'Not premium', 'volade-breadcrumbs' ); ?></span>
					<?php endif; ?>
				</p>
			<?php else : ?>
				<p class="description"><?php esc_html_e( 'Test the connection to verify premium entitlement. The result is cached afterwards.', 'volade-breadcrumbs' ); ?></p>
			<?php endif; ?>

			<div class="volade-actions">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'volade_test_premium' ); ?>
					<input type="hidden" name="action" value="volade_test_premium" />
					<button type="submit" class="button button-secondary volade-btn-secondary">
						<?php esc_html_e( 'Test Premium Status', 'volade-breadcrumbs' ); ?>
					</button>
				</form>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'volade_clear_premium_cache' ); ?>
					<input type="hidden" name="action" value="volade_clear_premium_cache" />
					<button type="submit" class="button volade-btn-link">
						<?php esc_html_e( 'Clear Premium Cache', 'volade-breadcrumbs' ); ?>
					</button>
				</form>
			</div>
		</div>

		<div class="volade-card">
			<h2>
				<span class="volade-card-icon" aria-hidden="true"><span class="dashicons dashicons-shield"></span></span>
				<?php esc_html_e( 'Settings Backup', 'volade-breadcrumbs' ); ?>
			</h2>

			<p class="description"><?php esc_html_e( 'Download your Volade settings as a JSON file, or import a file exported earlier. The file contains your API and license keys, so keep it private.', 'volade-breadcrumbs' ); ?></p>

			<div class="volade-actions">
				<a class="button button-secondary volade-btn-secondary" href="<?php echo esc_url( $export_url ); ?>">
					<?php esc_html_e( 'Export Settings', 'volade-breadcrumbs' ); ?>
				</a>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'volade-breadcrumbs_import_settings' ); ?>
					<input type="hidden" name="action" value="volade-breadcrumbs_import_settings" />
					<label class="screen-reader-text" for="volade-breadcrumbs_settings_file"><?php esc_html_e( 'Import Settings', 'volade-breadcrumbs' ); ?></label>
					<input type="file" id="volade-breadcrumbs_settings_file" name="volade-breadcrumbs_settings_file" class="volade-file" accept="application/json,.json" />
					<button type="submit" class="button button-secondary volade-btn-secondary">
						<?php esc_html_e( 'Import Settings', 'volade-breadcrumbs' ); ?>
					</button>
				</form>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'volade-breadcrumbs_restore_defaults' ); ?>
					<input type="hidden" name="action" value="volade-breadcrumbs_restore_defaults" />
					<button type="submit" class="button volade-btn-link">
						<?php esc_html_e( 'Restore Defaults', 'volade-breadcrumbs' ); ?>
					</button>
				</form>
			</div>

			<p class="description"><?php esc_html_e( 'Resets every Volade option to its default value and clears the cached entitlement.', 'volade-breadcrumbs' ); ?></p>
		</div>

		<div class="volade-card volade-card-muted">
			<h3>
				<span class="volade-card-icon" aria-hidden="true"><span class="dashicons dashicons-analytics"></span></span>
				<?php esc_html_e( 'System Information', 'volade-breadcrumbs' ); ?>
			</h3>
			<p class="description"><?php esc_html_e( 'Everything below is read locally: this page never sends a request.', 'volade-breadcrumbs' ); ?></p>

			<table class="volade-sysinfo">
				<caption class="screen-reader-text"><?php esc_html_e( 'System Information', 'volade-breadcrumbs' ); ?></caption>
				<tbody>
					<tr>
						<th scope="row"><?php esc_html_e( 'Plugin version', 'volade-breadcrumbs' ); ?></th>
						<td><?php echo esc_html( $info['plugin'] ); ?></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'WordPress version', 'volade-breadcrumbs' ); ?></th>
						<td><?php echo esc_html( $info['wp'] ); ?></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'PHP version', 'volade-breadcrumbs' ); ?></th>
						<td><?php echo esc_html( $info['php'] ); ?></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Last premium check', 'volade-breadcrumbs' ); ?></th>
						<td>
							<?php if ( $info['last_check'] ) : ?>
								<?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $info['last_check'] ) ); ?>
							<?php else : ?>
								<span aria-hidden="true">&mdash;</span>
							<?php endif; ?>
						</td>
					</tr>
				</tbody>
			</table>
		</div>

		<div class="volade-card volade-card-muted">
			<h3><?php esc_html_e( 'Cache Notes', 'volade-breadcrumbs' ); ?></h3>
			<p><?php esc_html_e( 'Successful premium checks are cached for 1 hour. Failed checks use a shorter 5-minute cache to avoid unnecessary API requests.', 'volade-breadcrumbs' ); ?></p>
		</div>
		<?php
	}

	/**
	 * About screen.
	 */
	private function view_about() {
		?>
		<div class="volade-card volade-breadcrumbs-about-hero">
			<img class="volade-breadcrumbs-about-logo" src="<?php echo esc_url( VOLADE_BREADCRUMBS_PLUGIN_URL . 'logo.png' ); ?>" alt="<?php echo esc_attr__( 'Volade Breadcrumbs', 'volade-breadcrumbs' ); ?>" width="96" height="96" />
			<div class="volade-breadcrumbs-about-intro">
				<h2><?php esc_html_e( 'About Volade', 'volade-breadcrumbs' ); ?></h2>
				<p><?php esc_html_e( 'Volade connects WordPress to the Volade ecosystem with a clean, WordPress.org-compliant freemium approach.', 'volade-breadcrumbs' ); ?></p>
			</div>
		</div>

		<div class="volade-card">
			<h3>
				<span class="volade-card-icon" aria-hidden="true"><span class="dashicons dashicons-awards"></span></span>
				<?php esc_html_e( 'Features', 'volade-breadcrumbs' ); ?>
			</h3>
			<ul class="volade-checklist">
				<li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e( 'Four ways to place the same trail: automatically, with a block, with a widget or with a shortcode.', 'volade-breadcrumbs' ); ?></li>
				<li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e( 'Categories, tags, custom taxonomies, post type, author and date archives, and the whole WooCommerce chain.', 'volade-breadcrumbs' ); ?></li>
				<li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e( 'Four style presets chosen from live previews, plus separator, homepage label, depth and post type switches.', 'volade-breadcrumbs' ); ?></li>
				<li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e( 'Hide the trail on one page from the editor, or hide the current page title from the settings.', 'volade-breadcrumbs' ); ?></li>
				<li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e( 'JSON-LD BreadcrumbList printed together with the trail, and never without it.', 'volade-breadcrumbs' ); ?></li>
				<li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e( 'Interface localised in 17 languages with flag selection.', 'volade-breadcrumbs' ); ?></li>
				<li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e( 'Free features work out of the box with no external configuration required.', 'volade-breadcrumbs' ); ?></li>
				<li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e( 'Premium entitlements are verified server-side via api.volade.com.', 'volade-breadcrumbs' ); ?></li>
				<li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e( 'No payments or checkout are handled inside this plugin.', 'volade-breadcrumbs' ); ?></li>
			</ul>
		</div>

		<div class="volade-card volade-card-muted">
			<h3>
				<span class="volade-card-icon" aria-hidden="true"><span class="dashicons dashicons-heart"></span></span>
				<?php esc_html_e( 'Support & Feedback', 'volade-breadcrumbs' ); ?>
			</h3>
			<p><?php esc_html_e( 'If you enjoy using Volade, please consider leaving a review on WordPress.org — it helps us improve and reach more users.', 'volade-breadcrumbs' ); ?></p>
			<p>
				<a href="https://wordpress.org/support/plugin/volade-breadcrumbs/reviews/#new-post" target="_blank" rel="noopener noreferrer" class="button button-secondary volade-btn-secondary">
					<?php esc_html_e( 'Leave a review on WordPress.org', 'volade-breadcrumbs' ); ?>
				</a>
			</p>
			<p>
				<?php esc_html_e( 'Want Volade news, releases and tips? Subscribe to our newsletter (external link):', 'volade-breadcrumbs' ); ?>
				<a href="<?php echo esc_url( Volade_Breadcrumbs_I18n::site_home_url() ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Join the Volade newsletter', 'volade-breadcrumbs' ); ?></a>
			</p>
		</div>

		<?php $this->render_external_services(); ?>
		<?php
	}

	/**
	 * External services disclosure (required by the WordPress.org guidelines).
	 *
	 * Legal links are resolved per interface language from the verified map in
	 * Volade_Breadcrumbs_I18n::SITE_PAGES, so no dead URL can ever be printed.
	 */
	private function render_external_services() {
		$terms_url   = Volade_Breadcrumbs_I18n::site_url( 'terms' );
		$privacy_url = Volade_Breadcrumbs_I18n::site_url( 'privacy' );
		?>
		<div class="volade-card volade-card-muted">
			<h3>
				<span class="volade-card-icon" aria-hidden="true"><span class="dashicons dashicons-admin-site"></span></span>
				<?php esc_html_e( 'External Services', 'volade-breadcrumbs' ); ?>
			</h3>
			<p><?php esc_html_e( 'When configured, this plugin may connect to api.volade.com to verify Premium entitlements. Only minimal technical data is transmitted (site URL, domain, plugin version and optional keys).', 'volade-breadcrumbs' ); ?></p>
			<p class="volade-legal-links">
				<a href="<?php echo esc_url( $terms_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Terms of Service', 'volade-breadcrumbs' ); ?></a>
				<span aria-hidden="true">&nbsp;•&nbsp;</span>
				<a href="<?php echo esc_url( $privacy_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Privacy Policy', 'volade-breadcrumbs' ); ?></a>
				<span aria-hidden="true">&nbsp;•&nbsp;</span>
				<a href="<?php echo esc_url( Volade_Breadcrumbs_I18n::site_url( 'faq' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Documentation', 'volade-breadcrumbs' ); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * Free vs Premium comparison (own screens only, honest upsell).
	 *
	 * Reads the cached entitlement only: rendering a marketing table must never
	 * trigger an outbound API request.
	 */
	private function render_premium_compare() {
		$upgrade_url = get_option( 'volade_upgrade_url', 'https://volade.com/' );
		$is_premium  = (bool) get_transient( Volade_Breadcrumbs_Premium::CACHE_KEY );

		$rows = array(
			array( __( 'Block, widget and shortcode placement', 'volade-breadcrumbs' ), true, true ),
			array( __( 'WooCommerce trail and primary category', 'volade-breadcrumbs' ), true, true ),
			array( __( 'Four style presets with live previews', 'volade-breadcrumbs' ), true, true ),
			array( __( 'Breadcrumb trail and schema markup', 'volade-breadcrumbs' ), true, true ),
			array( __( 'Volade ecosystem connection', 'volade-breadcrumbs' ), true, true ),
			array( __( 'Premium entitlement check', 'volade-breadcrumbs' ), true, true ),
			array( __( '17-language interface', 'volade-breadcrumbs' ), true, true ),
			array( __( 'Priority support', 'volade-breadcrumbs' ), false, true ),
			array( __( 'Advanced promotional tools on volade.com', 'volade-breadcrumbs' ), false, true ),
		);
		?>
		<div class="volade-card volade-card-muted">
			<h3>
				<span class="volade-card-icon" aria-hidden="true"><span class="dashicons dashicons-analytics"></span></span>
				<?php esc_html_e( 'Free vs Premium', 'volade-breadcrumbs' ); ?>
			</h3>

			<?php if ( $is_premium ) : ?>
				<p><span class="volade-badge volade-badge-success"><?php esc_html_e( 'Premium active on this site', 'volade-breadcrumbs' ); ?></span></p>
			<?php endif; ?>

			<table class="volade-compare">
				<caption class="screen-reader-text"><?php esc_html_e( 'Free vs Premium', 'volade-breadcrumbs' ); ?></caption>
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Feature', 'volade-breadcrumbs' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Free', 'volade-breadcrumbs' ); ?></th>
						<th scope="col" class="volade-col-pro"><?php esc_html_e( 'Premium', 'volade-breadcrumbs' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $rows as $row ) : ?>
						<tr>
							<th scope="row"><?php echo esc_html( $row[0] ); ?></th>
							<td class="<?php echo $row[1] ? 'volade-yes' : 'volade-no'; ?>">
								<span aria-hidden="true"><?php echo $row[1] ? '&#10003;' : '&#10005;'; ?></span>
								<span class="screen-reader-text"><?php echo $row[1] ? esc_html__( 'Included', 'volade-breadcrumbs' ) : esc_html__( 'Not included', 'volade-breadcrumbs' ); ?></span>
							</td>
							<td class="volade-col-pro <?php echo $row[2] ? 'volade-yes' : 'volade-no'; ?>">
								<span aria-hidden="true"><?php echo $row[2] ? '&#10003;' : '&#10005;'; ?></span>
								<span class="screen-reader-text"><?php echo $row[2] ? esc_html__( 'Included', 'volade-breadcrumbs' ) : esc_html__( 'Not included', 'volade-breadcrumbs' ); ?></span>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<p>
				<a href="<?php echo esc_url( $upgrade_url ); ?>" target="_blank" rel="noopener noreferrer" class="button volade-btn-primary">
					<?php esc_html_e( 'Discover Premium', 'volade-breadcrumbs' ); ?>
				</a>
			</p>
		</div>
		<?php
	}
}
