<?php
/**
 * API client.
 *
 * Connects to api.volade.com to verify Premium entitlements.
 *
 * @package Volade
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Volade_Breadcrumbs_API {

	/**
	 * Default API base URL.
	 */
	const DEFAULT_API_BASE = 'https://api.volade.com/v1';

	/**
	 * Check premium entitlement against the Volade API.
	 *
	 * Returns the raw wp_remote_post response, or WP_Error on transport failure.
	 *
	 * @return array|WP_Error
	 */
	public static function check_premium() {
		$base_url = get_option( 'volade_api_base_url', self::DEFAULT_API_BASE );
		$endpoint = get_option( 'volade_premium_endpoint', 'premium/check' );
		$api_key  = get_option( 'volade_api_key', '' );
		$license  = get_option( 'volade_license_key', '' );

		// Normalize base URL and endpoint.
		$base_url = rtrim( $base_url, '/' );
		$endpoint = ltrim( $endpoint, '/' );

		$url = $base_url . '/' . $endpoint;

		/**
		 * Final URL of the premium check request.
		 *
		 * Filter the URL before WordPress is asked to call it. Returning an
		 * external host is allowed only for a service the site admin has
		 * configured; nothing in Volade does this by default.
		 *
		 * @param string $url Fully built endpoint URL.
		 */
		$url = apply_filters( 'volade_api_url', $url );

		$home_url = home_url();
		$domain   = wp_parse_url( $home_url, PHP_URL_HOST );
		if ( empty( $domain ) ) {
			$domain = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
		}

		$body = array(
			'site_url'       => $home_url,
			'domain'         => $domain,
			'plugin_version' => VOLADE_BREADCRUMBS_VERSION,
			'plugin'         => 'volade-breadcrumbs',
		);

		if ( ! empty( $license ) ) {
			$body['license'] = $license;
		}

		/**
		 * Payload sent to api.volade.com.
		 *
		 * Runs before JSON encoding, so a site can add or drop fields without
		 * touching the plugin. The documented default contents are listed in
		 * readme.txt under External Services.
		 *
		 * @param array $body Request body.
		 */
		$body = apply_filters( 'volade_request_body', $body );

		$args = array(
			'timeout' => 20,
			'method'  => 'POST',
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Accept'        => 'application/json',
			),
			'body'    => wp_json_encode( $body ),
		);

		if ( ! empty( $api_key ) ) {
			$args['headers']['Authorization'] = 'Bearer ' . $api_key;
		}

		/**
		 * Arguments handed to wp_remote_post().
		 *
		 * @param array  $args Request arguments.
		 * @param string $url  Endpoint being called.
		 */
		$args = apply_filters( 'volade_request_args', $args, $url );

		return wp_remote_post( $url, $args );
	}

	/**
	 * Parse a premium response body into a boolean entitlement.
	 *
	 * Supports common field names so a schema mismatch does not break the plugin.
	 *
	 * @param string $body Raw response body.
	 * @return bool|null Null when the payload cannot be interpreted.
	 */
	public static function parse_premium( $body ) {
		$data = json_decode( $body, true );

		if ( ! is_array( $data ) ) {
			return null;
		}

		$keys = array( 'active', 'premium', 'is_premium', 'entitled', 'valid', 'success' );

		foreach ( $keys as $key ) {
			if ( isset( $data[ $key ] ) && is_bool( $data[ $key ] ) ) {
				return $data[ $key ];
			}
		}

		// Numeric or string-ish booleans (0/1, "true"/"false").
		foreach ( $keys as $key ) {
			if ( isset( $data[ $key ] ) && ! is_array( $data[ $key ] ) ) {
				$value = $data[ $key ];
				if ( is_bool( $value ) ) {
					return $value;
				}
				if ( is_numeric( $value ) ) {
					return (bool) (int) $value;
				}
				if ( is_string( $value ) ) {
					$filtered = filter_var( $value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE );
					if ( null !== $filtered ) {
						return $filtered;
					}
				}
			}
		}

		return null;
	}
}
