<?php
/**
 * Settings backup, restoration and local diagnostics.
 *
 * Everything in this file is local. The export is produced on demand from the
 * options already stored in the database, the import validates against a
 * whitelist of the option names this plugin owns and re-sanitises every value
 * before writing it, and the restore only ever writes defaults the plugin
 * defines itself. No method here opens a connection.
 *
 * @package Volade
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Volade_Breadcrumbs_Tools {

	/**
	 * Option recording that the Settings screen has been saved at least once.
	 *
	 * Drives the "Getting started" checklist on the Overview screen. It holds a
	 * timestamp, is never sent anywhere, and is removed on restore/uninstall.
	 */
	const SETUP_OPTION = 'volade_configured';

	/**
	 * Settings owned by the plugin: option name => sanitizer.
	 *
	 * This list is the single source of truth for export, import and restore,
	 * so a value can never be written by the import without passing through the
	 * exact sanitizer the Settings screen uses.
	 *
	 * @var array
	 */
	const OPTIONS = array(
		// Suite settings, shared with every other Volade plugin: one licence
		// covers the whole suite, so they are deliberately not renamed.
		'volade_api_base_url'     => 'esc_url_raw',
		'volade_premium_endpoint' => 'sanitize_text_field',
		'volade_api_key'          => 'sanitize_text_field',
		'volade_license_key'      => 'sanitize_text_field',
		'volade_upgrade_url'      => 'esc_url_raw',
		'volade_language'         => array( 'Volade_Breadcrumbs_I18n', 'sanitize_language' ),

		// Settings of this plugin only.
		'volade_bc_enabled'       => 'sanitize_text_field',
		'volade_bc_post_types'    => array( 'Volade_Breadcrumbs_Trail', 'sanitize_post_types' ),
		'volade_bc_show_home'     => 'sanitize_text_field',
		'volade_bc_home'          => 'sanitize_text_field',
		'volade_bc_hide_home'     => 'sanitize_text_field',
		'volade_bc_separator'     => 'sanitize_text_field',
		'volade_bc_style'         => array( 'Volade_Breadcrumbs_Trail', 'sanitize_style' ),
		'volade_bc_depth'         => 'absint',
		'volade_bc_schema'        => 'sanitize_text_field',
		'volade_bc_hide_title'    => 'sanitize_text_field',
		'volade_bc_woo'           => 'sanitize_text_field',
	);

	/**
	 * Default value of every owned setting.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'volade_api_base_url'     => Volade_Breadcrumbs_API::DEFAULT_API_BASE,
			'volade_premium_endpoint' => 'premium/check',
			'volade_api_key'          => '',
			'volade_license_key'      => '',
			'volade_upgrade_url'      => 'https://volade.com/',
			'volade_language'         => '',

			'volade_bc_enabled'       => '1',
			'volade_bc_post_types'    => '',
			'volade_bc_show_home'     => '1',
			'volade_bc_home'          => '',
			'volade_bc_hide_home'     => '1',
			'volade_bc_separator'     => '/',
			'volade_bc_style'         => 'default',
			'volade_bc_depth'         => '0',
			'volade_bc_schema'        => '1',
			'volade_bc_hide_title'    => '0',
			'volade_bc_woo'           => '1',
		);
	}

	/**
	 * Build the download payload from the stored options.
	 *
	 * @return array
	 */
	public static function export_payload() {
		$defaults = self::defaults();
		$settings = array();

		foreach ( self::OPTIONS as $option => $sanitizer ) {
			$settings[ $option ] = get_option( $option, $defaults[ $option ] );
		}

		return array(
			'plugin'      => 'volade-breadcrumbs',
			'version'     => VOLADE_BREADCRUMBS_VERSION,
			'exported_at' => gmdate( 'c' ),
			'settings'    => $settings,
		);
	}

	/**
	 * Apply a previously exported payload to the database.
	 *
	 * Accepts only a map containing at least one option this plugin owns, and
	 * sanitises each value through the same callback the Settings screen uses,
	 * so a tampered file cannot write an unsanitised value.
	 *
	 * @param string $raw Raw file contents.
	 * @return bool True when at least one setting was written.
	 */
	public static function import_raw( $raw ) {
		$data = json_decode( (string) $raw, true );

		if ( ! is_array( $data ) || ! isset( $data['settings'] ) || ! is_array( $data['settings'] ) ) {
			return false;
		}

		$settings = $data['settings'];
		$written  = 0;

		foreach ( self::OPTIONS as $option => $sanitizer ) {
			if ( ! array_key_exists( $option, $settings ) ) {
				continue;
			}

			$value = $settings[ $option ];

			// Objects and arrays are never valid here: every owned setting is
			// a scalar, and accepting a structure would bypass the sanitizer.
			if ( is_array( $value ) || is_object( $value ) ) {
				continue;
			}

			$clean = is_callable( $sanitizer )
				? call_user_func( $sanitizer, $value )
				: sanitize_text_field( (string) $value );

			update_option( $option, $clean );
			$written++;
		}

		if ( $written > 0 ) {
			do_action( 'volade_settings_imported', $written );
		}

		return ( $written > 0 );
	}

	/**
	 * Put every owned setting back to its default and drop the cached results.
	 *
	 * @return bool Always true once the defaults have been written.
	 */
	public static function apply_defaults() {
		foreach ( self::defaults() as $option => $value ) {
			update_option( $option, $value );
		}

		delete_option( self::SETUP_OPTION );
		delete_transient( Volade_Breadcrumbs_Premium::CACHE_KEY );
		delete_transient( Volade_Breadcrumbs_Premium::LAST_TEST );

		do_action( 'volade_settings_restored' );

		return true;
	}

	/**
	 * Locally gathered facts for the System Information table.
	 *
	 * Reads the database and the runtime only; nothing here reaches out.
	 *
	 * @return array
	 */
	public static function system_info() {
		$last = Volade_Breadcrumbs_Premium::get_last_test();

		return array(
			'plugin'     => VOLADE_BREADCRUMBS_VERSION,
			'wp'         => (string) get_bloginfo( 'version' ),
			'php'        => PHP_VERSION,
			'last_check' => ( is_array( $last ) && isset( $last['time'] ) ) ? (int) $last['time'] : 0,
		);
	}

	/**
	 * Translate a whitelisted notice key coming back from the redirect.
	 *
	 * Only three keys are known, so no attacker-controlled string can ever
	 * reach the screen.
	 *
	 * @param string $key Raw query value.
	 * @return array|null { type, text } or null when the key is unknown.
	 */
	public static function notice_from_key( $key ) {
		$map = array(
			'imported' => array( 'type' => 'success', 'text' => __( 'Settings imported.', 'volade-breadcrumbs' ) ),
			'restored' => array( 'type' => 'success', 'text' => __( 'Settings restored to defaults.', 'volade-breadcrumbs' ) ),
			'invalid'  => array( 'type' => 'error', 'text' => __( 'That file could not be read as a Volade settings export.', 'volade-breadcrumbs' ) ),
		);

		$key = sanitize_key( (string) $key );

		return isset( $map[ $key ] ) ? $map[ $key ] : null;
	}

	/**
	 * Notice to display after a Post/Redirect/Get cycle, if any.
	 *
	 * @return array|null
	 */
	public static function current_notice() {
		if ( empty( $_GET['volade_notice'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- flag written by our own redirect; notice_from_key() only accepts a fixed list of keys.
			return null;
		}

		return self::notice_from_key( sanitize_key( wp_unslash( $_GET['volade_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification -- flag written by our own redirect, whitelisted against known keys.
	}

	/**
	 * Redirect back to Tools with a whitelisted notice key.
	 *
	 * @param string $key One of imported|restored|invalid.
	 */
	private static function back_to_tools( $key ) {
		$redirect = add_query_arg(
			array(
				'page'          => 'volade-breadcrumbs-tools',
				'volade_notice' => sanitize_key( $key ),
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * admin-post handler: download the settings as JSON.
	 */
	public static function handle_export() {
		if ( ! current_user_can( Volade_Breadcrumbs_Admin::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'volade-breadcrumbs' ) );
		}

		check_admin_referer( 'volade-breadcrumbs_export_settings' );

		$payload = apply_filters( 'volade_export_payload', self::export_payload() );
		$name    = 'volade-breadcrumbs-settings-' . gmdate( 'Y-m-d' ) . '.json';

		nocache_headers();
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );

		wp_send_json( $payload );
	}

	/**
	 * admin-post handler: import a settings file, then redirect (PRG).
	 */
	public static function handle_import() {
		if ( ! current_user_can( Volade_Breadcrumbs_Admin::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'volade-breadcrumbs' ) );
		}

		check_admin_referer( 'volade-breadcrumbs_import_settings' );

		$raw = '';

		/*
		 * $_FILES is read key by key so every value is sanitised where it is
		 * used: only the transfer error code and the temporary path matter
		 * here, neither is ever printed, and the path is PHP's own.
		 */
		$error = UPLOAD_ERR_NO_FILE;
		$tmp   = '';

		if ( isset( $_FILES['volade-breadcrumbs_settings_file']['error'] ) ) {
			$error = absint( $_FILES['volade-breadcrumbs_settings_file']['error'] );
		}

		if ( UPLOAD_ERR_OK === $error && isset( $_FILES['volade-breadcrumbs_settings_file']['tmp_name'] ) ) {
			$tmp = sanitize_text_field( wp_unslash( $_FILES['volade-breadcrumbs_settings_file']['tmp_name'] ) );
		}

		if ( '' !== $tmp ) {
			$raw = (string) file_get_contents( $tmp );
		}

		self::back_to_tools( self::import_raw( $raw ) ? 'imported' : 'invalid' );
	}

	/**
	 * admin-post handler: restore defaults, then redirect (PRG).
	 */
	public static function handle_restore() {
		if ( ! current_user_can( Volade_Breadcrumbs_Admin::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'volade-breadcrumbs' ) );
		}

		check_admin_referer( 'volade-breadcrumbs_restore_defaults' );

		self::apply_defaults();

		self::back_to_tools( 'restored' );
	}
}
