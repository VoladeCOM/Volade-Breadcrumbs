<?php
/**
 * Gutenberg block for the trail.
 *
 * A dynamic block: the editor script only draws a preview from the real CSS
 * that ships with the plugin, and PHP renders the actual trail on the way out,
 * so the markup in a saved post can never drift from the trail the settings
 * ask for. No build step, no compiled bundle, no third party code.
 *
 * The block exists because the shortcode cannot be picked from the inserter,
 * and because every competing breadcrumbs plugin ships one.
 *
 * @package Volade
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Volade_Breadcrumbs_Block {

	/**
	 * Handle of the editor script, reused as the name of its data payload.
	 */
	const HANDLE = 'volade-breadcrumbs-block';

	/**
	 * Wire the two hooks this class needs.
	 */
	public static function hooks() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'editor_styles' ) );
	}

	/**
	 * Register the block with WordPress.
	 */
	public static function register() {
		$src = VOLADE_BREADCRUMBS_PLUGIN_URL . 'assets/js/breadcrumbs-block.js';
		$ver = Volade_Breadcrumbs_Admin::asset_version( 'assets/js/breadcrumbs-block.js' );

		wp_register_script( self::HANDLE, $src, array(
			'wp-blocks',
			'wp-element',
			'wp-i18n',
			'wp-block-editor',
			'wp-components',
			'wp-data',
		), $ver, true );

		wp_localize_script( self::HANDLE, 'voladeBreadcrumbsBlock', self::payload() );

		register_block_type( 'volade/breadcrumbs', array(
			'editor_script' => self::HANDLE,
			'render_callback' => array( __CLASS__, 'render' ),
			'attributes'     => array(
				'style' => array(
					'type'    => 'string',
					'default' => '',
				),
			),
		) );
	}

	/**
	 * Everything the editor script needs, already in the site language.
	 *
	 * Localising from PHP is what keeps the block translatable through the
	 * same .po files as the rest of the plugin: a block.json translation file
	 * would have needed a second pipeline nobody would ever keep in step.
	 *
	 * @return array
	 */
	private static function payload() {
		$styles = array( array(
			'label' => __( 'Same as settings', 'volade-breadcrumbs' ),
			'value' => '',
		) );

		foreach ( Volade_Breadcrumbs_Trail::styles() as $slug => $label ) {
			$styles[] = array(
				'label' => $label,
				'value' => $slug,
			);
		}

		return array(
			'title'       => __( 'Breadcrumb trail', 'volade-breadcrumbs' ),
			'description' => __( 'Add a breadcrumb trail to your content.', 'volade-breadcrumbs' ),
			'settings'    => __( 'Style', 'volade-breadcrumbs' ),
			'styles'      => $styles,
			// Labels of the static preview drawn inside the editor.
			'home'        => __( 'Home', 'volade-breadcrumbs' ),
			'untitled'    => __( 'Untitled', 'volade-breadcrumbs' ),
			'separator'   => trim( (string) get_option( 'volade_bc_separator', '/' ) ) ?: '/',
		);
	}

	/**
	 * Give the editor the same stylesheet the site visitor gets, so the
	 * preview is the trail itself and not an approximation of it.
	 */
	public static function editor_styles() {
		if ( ! wp_script_is( self::HANDLE, 'registered' ) ) {
			return;
		}

		wp_enqueue_style(
			'volade-breadcrumbs-front',
			VOLADE_BREADCRUMBS_PLUGIN_URL . 'assets/css/breadcrumbs.css',
			array(),
			Volade_Breadcrumbs_Admin::asset_version( 'assets/css/breadcrumbs.css' )
		);
	}

	/**
	 * Render the block on the front end.
	 *
	 * @param array $attributes Block attributes.
	 * @return string
	 */
	public static function render( $attributes ) {
		$style = isset( $attributes['style'] ) ? (string) $attributes['style'] : '';

		return Volade_Breadcrumbs_Trail::render( array( 'style' => $style ) );
	}
}
