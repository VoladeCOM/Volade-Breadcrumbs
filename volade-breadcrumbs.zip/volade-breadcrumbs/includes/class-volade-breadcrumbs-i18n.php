<?php
/**
 * Internationalisation & language selector.
 *
 * 17 interface languages, selected with flag icons (SVG, no emoji).
 * The selection only affects the Volade plugin screens, never the whole site.
 *
 * @package Volade
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Volade_Breadcrumbs_I18n {

	/**
	 * Option name storing the chosen interface language ('' = follow WordPress).
	 */
	const OPTION = 'volade_language';

	/**
	 * Supported languages.
	 *
	 * Each entry: WordPress locale, native label, SVG flag file, text direction.
	 *
	 * @var array
	 */
	const LANGUAGES = array(
		array( 'locale' => 'fr_FR', 'label' => 'Français',          'flag' => 'fr', 'dir' => 'ltr' ),
		array( 'locale' => 'en_US', 'label' => 'English',           'flag' => 'gb', 'dir' => 'ltr' ),
		array( 'locale' => 'es_ES', 'label' => 'Español',           'flag' => 'es', 'dir' => 'ltr' ),
		array( 'locale' => 'de_DE', 'label' => 'Deutsch',           'flag' => 'de', 'dir' => 'ltr' ),
		array( 'locale' => 'pt_PT', 'label' => 'Português',         'flag' => 'pt', 'dir' => 'ltr' ),
		array( 'locale' => 'zh_CN', 'label' => '中文',               'flag' => 'cn', 'dir' => 'ltr' ),
		array( 'locale' => 'hi_IN', 'label' => 'हिन्दी',              'flag' => 'in', 'dir' => 'ltr' ),
		array( 'locale' => 'ar',    'label' => 'العربية',            'flag' => 'sa', 'dir' => 'rtl' ),
		array( 'locale' => 'ru_RU', 'label' => 'Русский',            'flag' => 'ru', 'dir' => 'ltr' ),
		array( 'locale' => 'id_ID', 'label' => 'Bahasa Indonesia',   'flag' => 'id', 'dir' => 'ltr' ),
		array( 'locale' => 'ja_JP', 'label' => '日本語',              'flag' => 'jp', 'dir' => 'ltr' ),
		array( 'locale' => 'it_IT', 'label' => 'Italiano',           'flag' => 'it', 'dir' => 'ltr' ),
		array( 'locale' => 'tr_TR', 'label' => 'Türkçe',             'flag' => 'tr', 'dir' => 'ltr' ),
		array( 'locale' => 'ko_KR', 'label' => '한국어',              'flag' => 'kr', 'dir' => 'ltr' ),
		array( 'locale' => 'nl_NL', 'label' => 'Nederlands',         'flag' => 'nl', 'dir' => 'ltr' ),
		array( 'locale' => 'pl_PL', 'label' => 'Polski',             'flag' => 'pl', 'dir' => 'ltr' ),
		array( 'locale' => 'vi',    'label' => 'Tiếng Việt',         'flag' => 'vn', 'dir' => 'ltr' ),
	);

	/**
	 * Sanitize a submitted language value.
	 *
	 * @param string $value Raw value.
	 * @return string Valid locale, or '' to follow WordPress.
	 */
	public static function sanitize_language( $value ) {
		$value = sanitize_text_field( (string) $value );

		if ( '' === $value ) {
			return '';
		}

		return self::is_supported( $value ) ? $value : '';
	}

	/**
	 * Is this locale supported by the plugin?
	 *
	 * @param string $locale Locale to check.
	 * @return bool
	 */
	public static function is_supported( $locale ) {
		foreach ( self::LANGUAGES as $lang ) {
			if ( $lang['locale'] === $locale ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Stored language selection ('' = follow WordPress).
	 *
	 * @return string
	 */
	public static function get_stored_language() {
		return (string) get_option( self::OPTION, '' );
	}

	/**
	 * Effective locale used by this plugin.
	 *
	 * @return string
	 */
	public static function get_locale() {
		$stored = self::get_stored_language();

		if ( '' !== $stored && self::is_supported( $stored ) ) {
			return $stored;
		}

		return determine_locale();
	}

	/**
	 * Is the effective interface in right-to-left?
	 *
	 * @return bool
	 */
	public static function is_rtl() {
		foreach ( self::LANGUAGES as $lang ) {
			if ( $lang['locale'] === self::get_locale() && 'rtl' === $lang['dir'] ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * URL of a flag SVG.
	 *
	 * @param string $flag Flag file name without extension (e.g. 'fr').
	 * @return string
	 */
	public static function flag_url( $flag ) {
		return VOLADE_BREADCRUMBS_PLUGIN_URL . 'assets/flags/' . sanitize_file_name( $flag ) . '.svg';
	}

	/**
	 * 2-letter volade.com edition code for the effective locale.
	 *
	 * Verified against the 17 editions published in the volade.com switcher.
	 *
	 * @return string
	 */
	public static function site_language() {
		$code   = strtolower( substr( self::get_locale(), 0, 2 ) );
		$valid  = array( 'ar', 'de', 'en', 'es', 'fr', 'hi', 'id', 'it', 'ja',
			'ko', 'nl', 'pl', 'pt', 'ru', 'tr', 'vi', 'zh' );

		return in_array( $code, $valid, true ) ? $code : 'en';
	}

	/**
	 * Verified volade.com page map: page key => edition code => file name.
	 *
	 * Every entry below was probed live and returned HTTP 200. A page key
	 * resolves to the current edition when it exists there, otherwise to the
	 * English edition, otherwise to that edition's home page.
	 *
	 * @var array
	 */
	const SITE_PAGES = array(
		'faq'     => array(
			'fr' => 'faq.html', 'en' => 'faq.html', 'es' => 'faq.html',
			'de' => 'faq.html', 'pt' => 'faq.html', 'zh' => 'faq.html',
			'hi' => 'faq.html', 'ar' => 'faq.html', 'ru' => 'faq.html',
			'id' => 'faq.html', 'ja' => 'faq.html', 'it' => 'faq.html',
			'ko' => 'faq.html', 'nl' => 'faq.html', 'pl' => 'faq.html',
			'vi' => 'faq.html', // tr has no FAQ edition yet.
		),
		'terms'   => array(
			'fr' => 'cgu.html',
			'en' => 'terms.html',
			'nl' => 'terms.html',
			'pl' => 'terms.html',
			'vi' => 'terms.html',
		),
		'privacy' => array(
			'fr'  => 'confidentialite.html',
			'en'  => 'privacy.html',
			'it'  => 'privacy.html',
			'nl'  => 'privacy.html',
			'pl'  => 'privacy.html',
			'vi'  => 'privacy.html',
		),
	);

	/**
	 * Home page of the current volade.com edition (newsletter form lives there).
	 *
	 * @return string
	 */
	public static function site_home_url() {
		return 'https://volade.com/' . self::site_language() . '/';
	}

	/**
	 * Verified volade.com URL for a known page key.
	 *
	 * @param string $page One of the keys in SITE_PAGES.
	 * @return string
	 */
	public static function site_url( $page ) {
		$lang = self::site_language();

		if ( ! isset( self::SITE_PAGES[ $page ] ) ) {
			return self::site_home_url();
		}

		$pages = self::SITE_PAGES[ $page ];

		// Preferred edition, then English, then the first edition available.
		if ( isset( $pages[ $lang ] ) ) {
			return 'https://volade.com/' . $lang . '/' . $pages[ $lang ];
		}

		if ( isset( $pages['en'] ) ) {
			return 'https://volade.com/en/' . $pages['en'];
		}

		$first = array_key_first( $pages );
		$file  = (string) $pages[ $first ];

		return 'https://volade.com/' . $first . '/' . $file;
	}

	/**
	 * Load the plugin translations for the effective locale.
	 *
	 * No translation files are bundled: WordPress.org generates the language
	 * packs from translate.wordpress.org and installs them in
	 * WP_LANG_DIR/plugins, which is the only location probed here.
	 *
	 * Deliberately no manual textdomain-loading call: Plugin Check reports that
	 * helper as discouraged for a plugin hosted on WordPress.org, and the
	 * location it would search is the one checked above. With no file present
	 * the English source strings are simply what ships.
	 */
	public static function load_textdomain() {
		$locale = self::get_locale();
		$domain = 'volade-breadcrumbs';

		// Language pack installed by WordPress.org.
		$mofile = WP_LANG_DIR . '/plugins/' . $domain . '-' . $locale . '.mo';

		if ( file_exists( $mofile ) ) {
			load_textdomain( $domain, $mofile );
		}
	}

	/**
	 * Register the language setting.
	 */
	public static function register_setting() {
		register_setting(
			'volade-breadcrumbs_settings_language',
			self::OPTION,
			array(
				'sanitize_callback' => array( __CLASS__, 'sanitize_language' ),
				'default'           => '',
			)
		);
	}

	/**
	 * Render the language picker (flag grid).
	 */
	public static function render_field() {
		$current = self::get_stored_language();

		// "Follow WordPress" option first.
		?>
		<fieldset class="volade-lang-grid">
			<label class="volade-lang<?php echo ( '' === $current ) ? ' is-selected' : ''; ?>">
				<input type="radio" name="<?php echo esc_attr( self::OPTION ); ?>" value="" <?php checked( $current, '' ); ?> />
				<span class="volade-lang-badge"><?php esc_html_e( 'Auto', 'volade-breadcrumbs' ); ?></span>
				<span class="volade-lang-label"><?php esc_html_e( 'Follow WordPress', 'volade-breadcrumbs' ); ?></span>
			</label>

			<?php foreach ( self::LANGUAGES as $lang ) : ?>
				<label class="volade-lang<?php echo ( $lang['locale'] === $current ) ? ' is-selected' : ''; ?>">
					<input type="radio" name="<?php echo esc_attr( self::OPTION ); ?>" value="<?php echo esc_attr( $lang['locale'] ); ?>" <?php checked( $current, $lang['locale'] ); ?> />
					<img class="volade-flag" src="<?php echo esc_url( self::flag_url( $lang['flag'] ) ); ?>" alt="" width="24" height="16" loading="lazy" />
					<span class="volade-lang-label"><?php echo esc_html( $lang['label'] ); ?></span>
				</label>
			<?php endforeach; ?>
		</fieldset>
		<p class="description">
			<?php esc_html_e( 'This changes the language of the Volade screens only, never your whole site.', 'volade-breadcrumbs' ); ?>
		</p>
		<?php
	}
}
