<?php
/**
 * Widget version of the trail.
 *
 * The same trail, in a widget area, for themes where neither the automatic
 * placement nor a template call is convenient. It carries no logic of its
 * own: it renders through Volade_Breadcrumbs_Trail::render(), so a site can
 * never end up with two different breadcrumbs depending on where they come
 * from.
 *
 * @package Volade
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Volade_Breadcrumbs_Widget extends WP_Widget {

	/**
	 * Register the widget with WordPress.
	 */
	public static function hooks() {
		add_action( 'widgets_init', array( __CLASS__, 'register' ) );
	}

	/**
	 * Register the widget class.
	 */
	public static function register() {
		register_widget( __CLASS__ );
	}

	/**
	 * Set the widget up.
	 */
	public function __construct() {
		parent::__construct(
			'volade_breadcrumbs',
			__( 'Volade Breadcrumbs', 'volade-breadcrumbs' ),
			array(
				'classname'   => 'volade-breadcrumbs-widget',
				'description' => __( 'Shows the breadcrumb trail for the current page.', 'volade-breadcrumbs' ),
			)
		);
	}

	/**
	 * Front end: print the trail.
	 *
	 * @param array $args     Sidebar arguments from the theme.
	 * @param array $instance Saved widget settings.
	 */
	public function widget( $args, $instance ) {
		$trail = Volade_Breadcrumbs_Trail::render();

		if ( '' === $trail ) {
			return;
		}

		$title = isset( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : '';

		echo isset( $args['before_widget'] ) ? $args['before_widget'] : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- theme-supplied wrapper, same as core.

		if ( '' !== $title ) {
			echo isset( $args['before_title'] ) ? $args['before_title'] : '<h2 class="volade-bc-title">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- theme-supplied wrapper, same as core.
			echo esc_html( $title );
			echo isset( $args['after_title'] ) ? $args['after_title'] : '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- theme-supplied wrapper, same as core.
		}

		echo $trail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- already escaped by Trail::render().

		echo isset( $args['after_widget'] ) ? $args['after_widget'] : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- theme-supplied wrapper, same as core.
	}

	/**
	 * Back end: the optional heading.
	 *
	 * @param array $instance Saved widget settings.
	 */
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? (string) $instance['title'] : '';

		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
				<?php echo esc_html__( 'Title', 'volade-breadcrumbs' ); ?>
				<input class="widefat" type="text"
					id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
					name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"
					value="<?php echo esc_attr( $title ); ?>" />
			</label>
		</p>
		<p class="description">
			<?php echo esc_html__( 'The trail itself follows the plugin settings.', 'volade-breadcrumbs' ); ?>
		</p>
		<?php
	}

	/**
	 * Save the heading.
	 *
	 * @param array $new_instance Submitted values.
	 * @param array $old_instance Previous values.
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		return array(
			'title' => sanitize_text_field( isset( $new_instance['title'] ) ? $new_instance['title'] : '' ),
		);
	}
}
