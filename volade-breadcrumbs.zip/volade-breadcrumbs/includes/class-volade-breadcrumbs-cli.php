<?php
/**
 * WP-CLI commands.
 *
 *     wp volade status        Read the stored state without any network call.
 *     wp volade test          Run a premium entitlement check.
 *     wp volade clear-cache   Drop the cached entitlement and the last test.
 *
 * Output follows the WP-CLI convention of being English-only: it is developer
 * facing, never rendered to a site visitor, and WP-CLI itself translates
 * nothing either.
 *
 * The `test` command is the only one that talks to api.volade.com, and it runs
 * solely when you invoke it - the same explicit consent as the button on
 * Volade > Tools.
 *
 * @package Volade
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Volade_Breadcrumbs_CLI {

	/**
	 * Show the stored configuration and entitlement.
	 *
	 * Reads the database and the cached result only: this command never makes
	 * a request.
	 *
	 * ## EXAMPLES
	 *
	 *     wp volade status
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Associative arguments.
	 */
	public function status( $args, $assoc_args ) {
		$info = Volade_Breadcrumbs_Tools::system_info();
		$cached = get_transient( Volade_Breadcrumbs_Premium::CACHE_KEY );
		$last = Volade_Breadcrumbs_Premium::get_last_test();

		WP_CLI::log( sprintf( '%-22s %s', 'Plugin version', $info['plugin'] ) );
		WP_CLI::log( sprintf( '%-22s %s', 'WordPress version', $info['wp'] ) );
		WP_CLI::log( sprintf( '%-22s %s', 'PHP version', $info['php'] ) );
		WP_CLI::log( sprintf( '%-22s %s', 'API base URL', get_option( 'volade_api_base_url', Volade_Breadcrumbs_API::DEFAULT_API_BASE ) ) );
		WP_CLI::log( sprintf( '%-22s %s', 'License key', get_option( 'volade_license_key', '' ) !== '' ? 'set' : 'not set' ) );
		WP_CLI::log( sprintf( '%-22s %s', 'Interface language', Volade_Breadcrumbs_I18n::get_stored_language() !== '' ? Volade_Breadcrumbs_I18n::get_stored_language() : 'auto' ) );

		if ( false === $cached ) {
			WP_CLI::log( sprintf( '%-22s %s', 'Premium (cached)', 'not checked yet' ) );
		} else {
			WP_CLI::log( sprintf( '%-22s %s', 'Premium (cached)', $cached ? 'active' : 'not active' ) );
		}

		if ( is_array( $last ) && isset( $last['time'] ) ) {
			WP_CLI::log( sprintf( '%-22s %s', 'Last manual check', gmdate( 'c', (int) $last['time'] ) ) );
		}
	}

	/**
	 * Run a premium entitlement check against api.volade.com.
	 *
	 * Clears the cached result first so the answer is fresh, then stores the
	 * new outcome like the Tools screen does.
	 *
	 * ## EXAMPLES
	 *
	 *     wp volade test
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Associative arguments.
	 */
	public function test( $args, $assoc_args ) {
		delete_transient( Volade_Breadcrumbs_Premium::CACHE_KEY );

		if ( Volade_Breadcrumbs_Premium::is_premium() ) {
			WP_CLI::success( 'Premium entitlement is active.' );
			return;
		}

		WP_CLI::warning( 'No active Premium entitlement (or the API could not be reached).' );
	}

	/**
	 * Delete the cached entitlement and the last manual test result.
	 *
	 * ## EXAMPLES
	 *
	 *     wp volade clear-cache
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Associative arguments.
	 */
	public function clear_cache( $args, $assoc_args ) {
		delete_transient( Volade_Breadcrumbs_Premium::CACHE_KEY );
		delete_transient( Volade_Breadcrumbs_Premium::LAST_TEST );

		WP_CLI::success( 'Volade caches cleared.' );
	}
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	WP_CLI::add_command( 'volade-breadcrumbs', 'Volade_Breadcrumbs_CLI' );
}
