<?php
/**
 * Front-end breadcrumb trail.
 *
 * Builds the trail from the queried object, prints it and, when enabled, a
 * JSON-LD BreadcrumbList right next to it. Everything here is local: the trail
 * is assembled from WordPress data already in the database, so rendering it
 * opens no connection and sends nothing anywhere.
 *
 * Printing the structured data from render() instead of wp_head() is what
 * keeps it honest - the schema appears if and only if the trail does, on
 * singular pages as well as behind the shortcode on archive pages.
 *
 * The trail understands: singular posts, pages and custom post types, the
 * archive page of a post type, category/tag/custom taxonomy terms, author and
 * date archives, and the WooCommerce hierarchy (shop, product categories,
 * product tags, single product).
 *
 * @package Volade
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Volade_Breadcrumbs_Trail {

	/**
	 * Wire the hooks this class needs.
	 */
	public static function hooks() {
		add_filter( 'the_content', array( __CLASS__, 'filter_content' ) );
		add_shortcode( 'volade_breadcrumbs', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	/**
	 * Read one of this plugin's settings, falling back to its default.
	 *
	 * Volade_Breadcrumbs_Tools::defaults() is the single source of truth for
	 * default values (it drives the export, the import and the restore too),
	 * so the trail never repeats a literal default of its own.
	 *
	 * @param string $name Option name.
	 * @return string
	 */
	private static function opt( $name ) {
		$defaults = Volade_Breadcrumbs_Tools::defaults();
		$value    = get_option( $name, isset( $defaults[ $name ] ) ? $defaults[ $name ] : '' );

		return is_scalar( $value ) ? (string) $value : '';
	}

	/**
	 * Enqueue the stylesheet only on requests that can print a trail.
	 */
	public static function assets() {
		if ( empty( self::build() ) ) {
			return;
		}

		wp_enqueue_style(
			'volade-breadcrumbs-front',
			VOLADE_BREADCRUMBS_PLUGIN_URL . 'assets/css/breadcrumbs.css',
			array(),
			Volade_Breadcrumbs_Admin::asset_version( 'assets/css/breadcrumbs.css' )
		);
	}

	/**
	 * Prepend the trail to the content of a singular item.
	 *
	 * A page that already carries the shortcode or the block keeps its manual
	 * placement instead of getting a second trail.
	 *
	 * @param string $content Post content.
	 * @return string
	 */
	public static function filter_content( $content ) {
		if ( is_admin() || ! is_singular() || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		$post = get_queried_object();

		if ( $post instanceof WP_Post && self::is_hidden( $post->ID ) ) {
			return $content;
		}

		if ( has_shortcode( $content, 'volade_breadcrumbs' ) || has_block( 'volade/breadcrumbs', $content ) ) {
			return $content;
		}

		$trail = self::render();

		return ( '' === $trail ) ? $content : $trail . $content;
	}

	/**
	 * [volade_breadcrumbs] shortcode.
	 *
	 * Works anywhere a shortcode does, including archive templates, which is
	 * where the automatic placement deliberately does not go.
	 *
	 * Recognised attributes: style, separator, hide_title, schema.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'style'      => '',
				'separator'  => '',
				'hide_title' => '',
				'schema'     => '',
			),
			$atts,
			'volade_breadcrumbs'
		);

		return self::render( $atts );
	}

	/**
	 * Whether the trail is switched off for one specific item.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public static function is_hidden( $post_id ) {
		return '1' === get_post_meta( (int) $post_id, '_volade_bc_hide', true );
	}

	/**
	 * Render the trail for the current query.
	 *
	 * @param array $overrides Per-call overrides: style, separator, hide_title,
	 *                         schema. Empty string means "use the saved setting".
	 * @return string Empty string when nothing should be shown.
	 */
	public static function render( $overrides = array() ) {
		$items = self::build();

		if ( empty( $items ) ) {
			return '';
		}

		$html = '';

		$schema = self::resolve( 'schema', $overrides, 'volade_bc_schema' );
		if ( '1' === $schema ) {
			$html .= self::schema( $items );
		}

		$separator = self::resolve( 'separator', $overrides, 'volade_bc_separator' );
		$separator = ( '' === $separator ) ? '/' : $separator;
		$style     = self::resolve( 'style', $overrides, 'volade_bc_style' );

		// "Hide the current item" drops the last crumb on screen but keeps it
		// in the schema: search engines want the full path, a reader standing
		// on the page does not need to be told where they already are.
		$hide_title = self::resolve( 'hide_title', $overrides, 'volade_bc_hide_title' );
		$display    = ( '1' === $hide_title && count( $items ) > 1 )
			? array_slice( $items, 0, count( $items ) - 1 )
			: $items;

		$last = count( $display ) - 1;

		// The four preset names stay written out inside the attribute: they are
		// the only proof, for the class-coverage audit, that the CSS variants
		// shipped in breadcrumbs.css are actually reachable.
		$html .= '<nav class="volade-bc '
			. ( 'minimal' === $style
				? 'volade-bc--minimal'
				: ( ( 'pill' === $style
					? 'volade-bc--pill'
					: ( ( 'numbered' === $style ) ? 'volade-bc--numbered' : 'volade-bc--default' ) ) )
			)
			. '" aria-label="' . esc_attr__( 'Breadcrumb', 'volade-breadcrumbs' ) . '">';
		$html .= '<ol class="volade-bc-list">';

		foreach ( $display as $index => $item ) {
			$html .= '<li class="volade-bc-item">';

			if ( ! empty( $item['current'] ) ) {
				$html .= '<span class="volade-bc-current" aria-current="page">' . esc_html( $item['label'] ) . '</span>';
			} else {
				$html .= '<a class="volade-bc-link" href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['label'] ) . '</a>';
			}

			if ( $index !== $last ) {
				$html .= '<span class="volade-bc-sep" aria-hidden="true">' . esc_html( $separator ) . '</span>';
			}

			$html .= '</li>';
		}

		$html .= '</ol></nav>';

		/*
		 * Same contract as volade_breadcrumbs_items: the markup is a value
		 * handed back, never printed here, and no licence stands between the
		 * caller and it.
		 */
		return (string) apply_filters( 'volade_breadcrumbs_html', $html, $items, $overrides );
	}

	/**
	 * Resolve one render argument against the saved setting.
	 *
	 * @param string $key      Argument name.
	 * @param array  $overrides Per-call overrides.
	 * @param string $option   Option name holding the saved default.
	 * @return string
	 */
	private static function resolve( $key, $overrides, $option ) {
		if ( isset( $overrides[ $key ] ) && '' !== (string) $overrides[ $key ] ) {
			return (string) $overrides[ $key ];
		}

		return self::opt( $option );
	}

	/**
	 * Trail for the current query.
	 *
	 * Every item carries its own URL even when it is the current page: the
	 * markup renders the current page as text, but schema.org expects a
	 * position and a URL for every node of the list.
	 *
	 * @return array List of { label, url, current }.
	 */
	private static function build() {
		if ( '1' !== self::opt( 'volade_bc_enabled' ) ) {
			return array();
		}

		$items = array();

		if ( is_front_page() ) {
			if ( '1' === self::opt( 'volade_bc_hide_home' ) ) {
				return array();
			}

			$items = array( self::home_item( true ) );
		} elseif ( is_singular() ) {
			$items = self::singular_items( get_queried_object() );
		} elseif ( is_category() || is_tag() || is_tax() ) {
			$items = self::term_items( get_queried_object() );
		} elseif ( is_post_type_archive() ) {
			$items = array_merge(
				self::home_prefix(),
				array( self::archive_item( get_queried_object() ) )
			);
		} elseif ( is_author() ) {
			$items = array_merge(
				self::home_prefix(),
				array( self::author_item( get_queried_object() ) )
			);
		} elseif ( is_date() ) {
			$items = array_merge(
				self::home_prefix(),
				array( self::date_item() )
			);
		}

		$items = array_values( array_filter( $items ) );

		// Depth truncation keeps the root and drops the middle, which is the
		// level a reader never misses.
		$depth = (int) self::opt( 'volade_bc_depth' );

		if ( $depth > 0 && count( $items ) > $depth ) {
			$items = ( $depth > 1 )
				? array_merge( array( $items[0] ), array_slice( $items, 1 - $depth ) )
				: array( $items[0] );
		}

		/*
		 * The trail is handed out as a value, not printed from here, so
		 * anything that knows more about where the reader is standing than
		 * this file does - a search page, a 404, a forum, a multilingual
		 * plugin - can complete it or replace it.
		 *
		 * Deliberately unconditional: no licence is consulted, because a
		 * hook that a licence could switch off would mean shipping dead
		 * branches in the free package. An extension decides for itself
		 * whether it should run; this file only offers the value.
		 *
		 * Runs after the depth truncation, so the saved depth still governs
		 * what this file produced and the caller has the final say.
		 */
		return (array) apply_filters( 'volade_breadcrumbs_items', $items );
	}

	/**
	 * The homepage item.
	 *
	 * @param bool $current Whether this is the page being viewed.
	 * @return array
	 */
	private static function home_item( $current ) {
		$label = trim( self::opt( 'volade_bc_home' ) );

		if ( '' === $label ) {
			$label = __( 'Home', 'volade-breadcrumbs' );
		}

		return array(
			'label'   => $label,
			'url'     => home_url( '/' ),
			'current' => $current,
		);
	}

	/**
	 * The homepage item, unless it was switched off.
	 *
	 * @return array Zero or one item.
	 */
	private static function home_prefix() {
		if ( '1' !== self::opt( 'volade_bc_show_home' ) ) {
			return array();
		}

		return array( self::home_item( false ) );
	}

	/**
	 * Trail leading to a single post, page or custom post type item.
	 *
	 * @param mixed $post Queried object.
	 * @return array
	 */
	private static function singular_items( $post ) {
		if ( ! $post instanceof WP_Post ) {
			return array();
		}

		if ( ! in_array( $post->post_type, self::post_types(), true ) ) {
			return array();
		}

		$items = self::home_prefix();

		if ( 'product' === $post->post_type ) {
			$items = array_merge( $items, self::woo_shop_prefix() );
		}

		if ( 'page' === $post->post_type ) {
			foreach ( array_reverse( get_post_ancestors( $post ) ) as $ancestor_id ) {
				$items[] = array(
					'label'   => get_the_title( $ancestor_id ),
					'url'     => get_permalink( $ancestor_id ),
					'current' => false,
				);
			}
		} else {
			$items = array_merge( $items, self::taxonomy_items( $post ) );
		}

		$items[] = array(
			'label'   => get_the_title( $post ),
			'url'     => get_permalink( $post ),
			'current' => true,
		);

		return $items;
	}

	/**
	 * Ancestor chain of the first hierarchical term the item belongs to.
	 *
	 * Only hierarchical taxonomies describe a path: a tag is a label, not a
	 * level, so a flat taxonomy contributes nothing here.
	 *
	 * @param WP_Post $post Queried post.
	 * @return array
	 */
	private static function taxonomy_items( $post ) {
		$primary = self::primary_category_id( $post );

		foreach ( get_object_taxonomies( $post->post_type, 'names' ) as $taxonomy ) {
			if ( ! is_taxonomy_hierarchical( $taxonomy ) ) {
				continue;
			}

			$terms = get_the_terms( $post, $taxonomy );

			if ( ! is_array( $terms ) || empty( $terms ) ) {
				continue;
			}

			if ( $primary > 0 && 'category' === $taxonomy ) {
				foreach ( $terms as $index => $term ) {
					if ( (int) $term->term_id === $primary ) {
						// The editor picked a canonical branch; put it first so
						// the trail never jumps between two equally valid paths.
						unset( $terms[ $index ] );
						array_unshift( $terms, $term );
						break;
					}
				}
			}

			return self::term_chain( $terms[0], false );
		}

		return array();
	}

	/**
	 * The category another SEO plugin marked as canonical.
	 *
	 * Honours Yoast SEO and Rank Math when they are installed, so switching to
	 * Volade keeps the path a site owner already curated. Returns 0 when
	 * nothing was picked, which simply falls back to the first term.
	 *
	 * @param WP_Post $post Queried post.
	 * @return int
	 */
	private static function primary_category_id( $post ) {
		if ( ! in_array( $post->post_type, array( 'post', 'product' ), true ) ) {
			return 0;
		}

		foreach ( array( '_yoast_wpseo_primary_category', '_rank_math_primary_term' ) as $key ) {
			$id = (int) get_post_meta( $post->ID, $key, true );

			if ( $id > 0 && get_term( $id, 'category' ) instanceof WP_Term ) {
				return $id;
			}
		}

		return 0;
	}

	/**
	 * Trail leading to a category, tag or custom taxonomy term.
	 *
	 * @param mixed $term Queried term.
	 * @return array
	 */
	private static function term_items( $term ) {
		if ( ! $term instanceof WP_Term ) {
			return array();
		}

		$prefix = self::home_prefix();

		if ( in_array( $term->taxonomy, array( 'product_cat', 'product_tag' ), true ) ) {
			$prefix = array_merge( $prefix, self::woo_shop_prefix() );
		}

		return array_merge( $prefix, self::term_chain( $term, true ) );
	}

	/**
	 * A term and its ancestors, ancestors first.
	 *
	 * @param WP_Term $term    Term to start from.
	 * @param bool    $current Whether the term itself is the current page.
	 * @return array
	 */
	private static function term_chain( $term, $current ) {
		$chain = array();

		while ( $term instanceof WP_Term ) {
			$link = get_term_link( $term );

			if ( is_wp_error( $link ) ) {
				$link = '';
			}

			$chain[] = array(
				'label'   => $term->name,
				'url'     => $link,
				'current' => false,
			);

			$term = $term->parent ? get_term( $term->parent, $term->taxonomy ) : null;
		}

		$chain = array_reverse( $chain );

		if ( $current && ! empty( $chain ) ) {
			$last                    = count( $chain ) - 1;
			$chain[ $last ]['current'] = true;
		}

		return $chain;
	}

	/**
	 * The archive page of a post type.
	 *
	 * @param mixed $post_type Queried post type object or name.
	 * @return array|null
	 */
	private static function archive_item( $post_type ) {
		$name  = is_object( $post_type ) ? $post_type->name : (string) $post_type;
		$title = post_type_archive_title( '', false );
		$link  = post_type_archive_link( $name );

		if ( '' === $title || is_wp_error( $link ) || empty( $link ) ) {
			return null;
		}

		return array(
			'label'   => $title,
			'url'     => $link,
			'current' => true,
		);
	}

	/**
	 * The author archive page.
	 *
	 * @param mixed $author Queried author object.
	 * @return array|null
	 */
	private static function author_item( $author ) {
		if ( ! is_object( $author ) || empty( $author->display_name ) ) {
			return null;
		}

		$link = get_author_posts_url( $author->ID );

		if ( empty( $link ) || is_wp_error( $link ) ) {
			return null;
		}

		return array(
			'label'   => $author->display_name,
			'url'     => $link,
			'current' => true,
		);
	}

	/**
	 * The archive page of a year, month or day.
	 *
	 * wp_date() builds the label: it follows the site language without any
	 * string of ours having to be translated, and unlike
	 * get_the_archive_title() it never returns markup that would have to be
	 * stripped before the trail escapes it.
	 *
	 * @return array|null
	 */
	private static function date_item() {
		$year  = (int) get_query_var( 'year' );
		$month = (int) get_query_var( 'monthnum' );
		$day   = (int) get_query_var( 'day' );

		if ( is_year() ) {
			$stamp = mktime( 0, 0, 0, 1, 1, $year );
			$link  = get_year_link( $year );
			$label = wp_date( 'Y', $stamp );
		} elseif ( is_day() ) {
			$stamp = mktime( 0, 0, 0, $month, $day, $year );
			$link  = get_day_link( $year, $month, $day );
			$label = wp_date( 'j F Y', $stamp );
		} else {
			$stamp = mktime( 0, 0, 0, $month, 1, $year );
			$link  = get_month_link( $year, $month );
			$label = wp_date( 'F Y', $stamp );
		}

		if ( '' === trim( (string) $label ) || empty( $link ) || is_wp_error( $link ) ) {
			return null;
		}

		return array(
			'label'   => $label,
			'url'     => $link,
			'current' => true,
		);
	}

	/**
	 * The WooCommerce shop page, as one level above product categories.
	 *
	 * WooCommerce is detected by class name only: a site without it never
	 * loads this path, and a site with it gets one consistent trail instead of
	 * two competing ones.
	 *
	 * @return array Zero or one item.
	 */
	private static function woo_shop_prefix() {
		if ( ! self::is_woo() ) {
			return array();
		}

		if ( '1' !== self::opt( 'volade_bc_woo' ) ) {
			return array();
		}

		if ( ! function_exists( 'wc_get_page_id' ) ) {
			return array();
		}

		$shop_id = (int) wc_get_page_id( 'shop' );

		if ( $shop_id <= 0 ) {
			return array();
		}

		return array(
			array(
				'label'   => get_the_title( $shop_id ),
				'url'     => get_permalink( $shop_id ),
				'current' => false,
			),
		);
	}

	/**
	 * Whether the WooCommerce plugin is installed.
	 *
	 * @return bool
	 */
	private static function is_woo() {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Post types the trail is allowed to appear on.
	 *
	 * @return array List of post type names.
	 */
	public static function post_types() {
		$raw = trim( self::opt( 'volade_bc_post_types' ) );

		if ( '' === $raw ) {
			$public = get_post_types( array( 'public' => true ), 'names' );

			return array_values( array_diff( (array) $public, array( 'attachment' ) ) );
		}

		$wanted = array();

		foreach ( explode( ',', $raw ) as $slug ) {
			$slug = sanitize_key( $slug );

			if ( '' !== $slug ) {
				$wanted[] = $slug;
			}
		}

		return $wanted;
	}

	/**
	 * JSON-LD BreadcrumbList for the trail.
	 *
	 * @param array $items Trail items.
	 * @return string
	 */
	private static function schema( $items ) {
		$list     = array();
		$position = 1;

		foreach ( $items as $item ) {
			$list[] = array(
				'@type'    => 'ListItem',
				'position' => $position,
				'name'     => $item['label'],
				'item'     => $item['url'],
			);
			$position++;
		}

		$data = array(
			'@context'        => 'https://schema.org',
			'@type'           => 'BreadcrumbList',
			'itemListElement' => $list,
		);

		/*
		 * The node list before it is encoded, so an extension can enrich it
		 * without decoding the JSON back out of a string.
		 */
		$data = (array) apply_filters( 'volade_breadcrumbs_schema', $data, $items );

		return '<script type="application/ld+json">'
			. wp_json_encode( $data )
			. '</script>';
	}

	/**
	 * Sanitizer for the post type list.
	 *
	 * @param string $value Raw option value.
	 * @return string
	 */
	public static function sanitize_post_types( $value ) {
		$clean = array();

		foreach ( explode( ',', (string) $value ) as $slug ) {
			$slug = sanitize_key( $slug );

			if ( '' !== $slug ) {
				$clean[] = $slug;
			}
		}

		return implode( ',', $clean );
	}

	/**
	 * Sanitizer for the style preset.
	 *
	 * @param string $value Raw option value.
	 * @return string
	 */
	public static function sanitize_style( $value ) {
		$allowed = array( 'default', 'minimal', 'pill', 'numbered' );
		$value   = sanitize_key( $value );

		return in_array( $value, $allowed, true ) ? $value : 'default';
	}

	/**
	 * The style presets, in the order they appear on the Settings screen.
	 *
	 * Shared with the block, the widget and the settings preview so all four
	 * can never drift apart.
	 *
	 * @return array slug => translated label.
	 */
	public static function styles() {
		return array(
			'default' => __( 'Default', 'volade-breadcrumbs' ),
			'minimal' => __( 'Minimal', 'volade-breadcrumbs' ),
			'pill'    => __( 'Pill', 'volade-breadcrumbs' ),
			'numbered' => __( 'Numbered', 'volade-breadcrumbs' ),
		);
	}
}

/**
 * Print the breadcrumb trail for the current query.
 *
 * Template function, for themes that want the trail somewhere the automatic
 * placement cannot reach (a header, a page builder, a custom template).
 *
 * @param array $overrides Optional per-call overrides: style, separator,
 *                         hide_title, schema.
 * @return string The trail markup, already escaped.
 */
function volade_breadcrumbs( $overrides = array() ) {
	return Volade_Breadcrumbs_Trail::render( $overrides );
}

/**
 * Print only the JSON-LD BreadcrumbList for the current query.
 *
 * @return string The schema markup, or an empty string when there is no trail.
 */
function volade_breadcrumbs_json_ld() {
	$markup = Volade_Breadcrumbs_Trail::render( array( 'schema' => '1' ) );

	// Strip the visible trail, keep the script block.
	$markup = preg_replace( '/<nav\b[^>]*>.*?<\/nav>/is', '', $markup );

	return $markup;
}
