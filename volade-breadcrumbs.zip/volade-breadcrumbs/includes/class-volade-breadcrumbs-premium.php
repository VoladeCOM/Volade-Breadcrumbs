<?php
/**
 * Premium logic.
 *
 * Freemium gating with transient caching and graceful API failure.
 *
 * @package Volade
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Volade_Breadcrumbs_Premium {

	/**
	 * Transient cache key.
	 */
	const CACHE_KEY = 'volade_bc_premium_status';

	/**
	 * Cache TTL for a successful check (1 hour).
	 */
	const CACHE_TTL_SUCCESS = 3600;

	/**
	 * Cache TTL for a failed check (5 minutes).
	 */
	const CACHE_TTL_ERROR = 300;

	/**
	 * Transient holding the outcome of the last manual Tools test.
	 *
	 * Written by the admin_post handler, read by the Tools screen, so that the
	 * request never performs a network call while rendering a page (PRG).
	 *
	 * @var string
	 */
	const LAST_TEST = 'volade_bc_last_test';

	/**
	 * How long the manual test result stays visible on the Tools screen.
	 */
	const LAST_TEST_TTL = 900;

	/**
	 * @var Volade_Breadcrumbs_Premium
	 */
	private static $instance;

	/**
	 * @return Volade_Breadcrumbs_Premium
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_post_volade_clear_premium_cache', array( $this, 'clear_premium_cache' ) );
		add_action( 'admin_post_volade_test_premium', array( $this, 'test_premium' ) );
	}

	/**
	 * Manually refresh the entitlement cache (Tools screen).
	 *
	 * Runs as an admin_post handler so the work happens before the redirect
	 * (Post/Redirect/Get) instead of during a page render.
	 */
	public function test_premium() {
		if ( ! current_user_can( Volade_Breadcrumbs_Admin::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'volade-breadcrumbs' ) );
		}

		check_admin_referer( 'volade_test_premium' );

		delete_transient( self::CACHE_KEY );

		$premium = self::is_premium();

		set_transient(
			self::LAST_TEST,
			array(
				'premium' => (bool) $premium,
				'time'    => time(),
			),
			self::LAST_TEST_TTL
		);

		$redirect = add_query_arg(
			array( 'page' => 'volade-breadcrumbs-tools' ),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Last manual test outcome, or null when there is none to display.
	 *
	 * @return array|null
	 */
	public static function get_last_test() {
		$last = get_transient( self::LAST_TEST );

		if ( is_array( $last ) && isset( $last['premium'] ) ) {
			return $last;
		}

		return null;
	}

	/**
	 * Check if the current site has an active Premium entitlement.
	 *
	 * Fails gracefully: any API error is treated as non-premium with a short cache.
	 *
	 * @return bool
	 */
	public static function is_premium() {
		$cached = get_transient( self::CACHE_KEY );

		if ( false !== $cached ) {
			return (bool) $cached;
		}

		$response = Volade_Breadcrumbs_API::check_premium();

		if ( is_wp_error( $response ) ) {
			set_transient( self::CACHE_KEY, false, self::CACHE_TTL_ERROR );
			do_action( 'volade_premium_checked', false );
			return false;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		if ( $code < 200 || $code >= 300 ) {
			set_transient( self::CACHE_KEY, false, self::CACHE_TTL_ERROR );
			do_action( 'volade_premium_checked', false );
			return false;
		}

		$is_premium = Volade_Breadcrumbs_API::parse_premium( $body );

		if ( null === $is_premium ) {
			// Unreadable payload: treat as non-premium, short negative cache.
			set_transient( self::CACHE_KEY, false, self::CACHE_TTL_ERROR );
			do_action( 'volade_premium_checked', false );
			return false;
		}

		/**
		 * Entitlement after the API answered and the payload was parsed.
		 *
		 * Runs before the value is cached, so the filtered result is what
		 * every screen will show until the cache expires. Volade itself never
		 * alters the value; this exists so a site can reconcile the answer
		 * with its own licensing or force a state while developing.
		 *
		 * @param bool $is_premium Parsed entitlement.
		 */
		$is_premium = (bool) apply_filters( 'volade_premium_result', $is_premium );

		set_transient( self::CACHE_KEY, $is_premium, self::CACHE_TTL_SUCCESS );

		/**
		 * Fires once a check has reached the API and been cached.
		 *
		 * Not fired when the result came straight from the cache.
		 *
		 * @param bool $is_premium Cached entitlement.
		 */
		do_action( 'volade_premium_checked', $is_premium );

		return $is_premium;
	}

	/**
	 * Get the off-site upgrade URL.
	 *
	 * @return string
	 */
	public static function get_upgrade_url() {
		/**
		 * Off-site upgrade target.
		 *
		 * Keeps the paid-product link out of the plugin's settings so a site
		 * can point it at its own shop. WordPress.org requires upgrades to
		 * stay off-site (guideline 8), so this must remain an external URL.
		 *
		 * @param string $url Upgrade URL.
		 */
		$url = apply_filters( 'volade_upgrade_url', get_option( 'volade_upgrade_url', 'https://volade.com/' ) );

		return esc_url( $url );
	}

	/**
	 * Clear the premium cache (Tools tab).
	 */
	public function clear_premium_cache() {
		if ( ! current_user_can( Volade_Breadcrumbs_Admin::capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'volade-breadcrumbs' ) );
		}

		check_admin_referer( 'volade_clear_premium_cache' );

		delete_transient( self::CACHE_KEY );
		delete_transient( self::LAST_TEST );

		$redirect = add_query_arg(
			array(
				'page' => 'volade-breadcrumbs-tools',
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $redirect );
		exit;
	}
}
