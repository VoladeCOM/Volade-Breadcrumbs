=== Volade Breadcrumbs ===
Contributors: volade
Tags: breadcrumbs, navigation, schema, seo, structured-data
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Adds a breadcrumb trail with schema markup to your content, and verifies Volade Premium entitlements via api.volade.com.

== Description ==

Volade Breadcrumbs prints a breadcrumb trail above your posts, pages and custom post types, describes it with a schema.org BreadcrumbList so search engines understand where each page sits, and connects your site to the Volade ecosystem with a clean, WordPress.org-compliant freemium approach.

= Why this is different =

Everything below is verifiable in the plugin files, not a promise:

* **17 languages, translated by the community.** The interface is fully internationalised (148 strings, text domain `volade-breadcrumbs`) and localised through WordPress.org language packs, so translations are always current and update with WordPress. Languages are picked with SVG flag icons rather than emoji.
* **Rendering the trail opens no connection.** The trail, its stylesheet and its JSON-LD are built from data WordPress has already loaded. The plugin's only outbound request is the optional licence check, which gates no feature.
* **One renderer, five placements.** The automatic placement, the block, the widget, the `[volade_breadcrumbs]` shortcode and the `volade_breadcrumbs()` template function all call the same code, so the markup can never differ from one of them to another.
* **Four presets chosen from live previews** - default, minimal, pill and numbered - drawn with the stylesheet that actually ships, not described in a dropdown.
* **A per-page switch in the editor sidebar** that turns off the automatic placement for one item without touching a template, while an explicit block or shortcode still wins.
* **It follows the primary category you already picked in Yoast SEO or Rank Math**, so switching to Volade keeps the path you curated instead of jumping to the first term.
* **WooCommerce is supported, not required.** The shop chain appears when WooCommerce is present and is never loaded otherwise.
* **Nothing to fill in.** No account, no API key and no configuration are needed before the first post shows a trail.

= Features =

* Automatic trail above the content of single posts, pages and custom post types, with ancestor levels taken from the page hierarchy or from your hierarchical taxonomies.
* Three ways to place it: the automatic placement, a "Breadcrumb trail" block in the editor, and a widget for any widget area. A `[volade_breadcrumbs]` shortcode covers everything else, including archive templates.
* `volade_breadcrumbs()` and `volade_breadcrumbs_json_ld()` template functions for themes and page builders, so a trail can go anywhere the automatic placement cannot reach.
* Understands categories, tags and custom taxonomies, post type archives, author archives, date archives, and the WooCommerce chain: shop page, product categories, product tags, single product.
* Replaces WooCommerce's own breadcrumb, so a shop has one navigation instead of two competing ones.
* Follows the primary category already picked in Yoast SEO or Rank Math, so the trail never jumps between two equally valid paths.
* Hide the trail on one single page from the editor, without touching a template.
* Four visual presets (default, minimal, pill, numbered) shown as live previews you click to choose, plus a configurable separator, homepage label, optional maximum depth and a switch per post type.
* Hide the current page title from the trail, while search engines still receive the full path.
* JSON-LD BreadcrumbList printed only when the trail is, on the same request.
* Keyboard-visible focus ring, reduced-motion and higher-contrast support, print styles and a layout that wraps cleanly on a phone.
* Hidden on the homepage by default, since a trail of one level tells a reader nothing.
* Free features work out of the box, no external configuration required.
* Premium entitlements verified server-side via api.volade.com.
* No payments or checkout are handled inside this plugin.
* Graceful fallback: if the API is unreachable, the plugin treats the site as non-premium with a short cache, and never breaks the site.
* Dedicated top-level menu on the left of the dashboard, with a screen for Overview, Settings, License, Language, Tools and About.
* Interface localised into 17 languages through WordPress.org language packs, selected with flag icons (SVG, no emoji).
* Design and colour tokens taken verbatim from volade.com, so the admin screens match the site.
* Discreet marketing only: the Free vs Premium comparison, a review link and a newsletter link live on the plugin's own screens. No global admin notice is ever displayed.
* Backup tools on Volade Breadcrumbs > Tools: export every setting to a JSON file, import one back, or restore the defaults. Each operation is capability-checked, nonce-checked and validated against a whitelist of this plugin's own options.
* A System Information panel (plugin, WordPress and PHP versions, last check) that is read entirely locally: rendering it never sends a request.
* A short "Getting started" checklist on the Overview, computed from state already stored in your database. Nothing is locked behind it, and it sends nothing anywhere.
* Extension points for developers: actions and filters around the API call, the entitlement, the screens and the settings, plus `wp volade-breadcrumbs` WP-CLI commands.

== Installation ==

1. Upload the `volade-breadcrumbs` folder to the `/wp-content/plugins/` directory, or install it via the Plugins screen in WordPress.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. (Optional) Open the "Volade Breadcrumbs" menu on the left of the dashboard, then Settings, to tune the trail and the API connection.

== Frequently Asked Questions ==

= Where does the trail appear? =

Above the content of single posts, pages and custom post types that belong to the post types listed in Settings > Breadcrumbs. Leave that field empty to include every public type. The trail is hidden on the homepage by default, because a single level is noise; uncheck "Hide on the homepage" if you want it there.

= How do I place it myself? =

Three ways, all driven by the same settings:

* The **Breadcrumb trail block** in the editor (search for "breadcrumb"). It carries one option, the style, and follows your saved settings otherwise.
* The **breadcrumb widget**, for any widget area of your theme.
* The `[volade_breadcrumbs]` shortcode, which also accepts `style`, `separator`, `hide_title` and `schema` attributes for one placement.

Themes and page builders can call `volade_breadcrumbs()` directly, or `volade_breadcrumbs_json_ld()` when they only want the structured data.

On a post that already contains the block or the shortcode, the automatic placement steps aside so you never get two trails. Archive pages (categories, tags, custom taxonomies, post type archives, author and date archives) are placement territory: the automatic placement only runs in the content of a single item.

= Can I hide the trail on one page? =

Yes. Open the page in the editor and tick "Hide the breadcrumb trail on this page" in the Breadcrumbs box on the side. That switches off the automatic placement for that one item only; a trail you added with the block or the shortcode still shows, because an explicit placement is always more specific than a setting.

= Does it work with WooCommerce? =

Yes, when WooCommerce is installed. The trail runs Home > Shop > product category > product (and product tags the same way), and by default it replaces WooCommerce's own breadcrumb so a shop has one navigation instead of two. Untick "Replace the WooCommerce breadcrumb" in Settings to keep WooCommerce's own.

= Do I lose my primary category if I leave another SEO plugin? =

No. When a post has a primary category picked in Yoast SEO or Rank Math, the trail follows that branch rather than whatever term happens to come first. If nothing was picked, it falls back to the first hierarchical term.

= Does it slow my site down or phone home? =

No. The trail is built from data WordPress has already loaded, and its stylesheet is enqueued only on requests that can actually print a trail. Nothing in the breadcrumb code opens a connection. The only outbound request in this plugin is the premium check, which runs when you start it yourself (see External Services below).

= Does this plugin handle payments? =

No. Upgrades and license management happen off-site at https://volade.com/. No checkout is processed inside this plugin.

= What happens if the API is unavailable? =

The plugin fails gracefully: it treats the site as non-premium and caches that result for a short period (5 minutes) to avoid repeated requests. The site keeps working normally.

= What data is sent to api.volade.com? =

See the "External Services" section below.

= Which languages are supported? =

Arabic, Chinese, Dutch, English, French, German, Hindi, Indonesian, Italian, Japanese, Korean, Polish, Portuguese, Russian, Spanish, Turkish and Vietnamese. The selection only affects the Volade screens, never the rest of your site.

= Can I extend Volade from my own plugin? =

Yes. Volade exposes actions and filters, so you never have to edit its files:

* `volade_admin_capability` - capability required to reach the Volade screens (default `manage_options`).
* `volade_api_url` - final URL of the premium check request.
* `volade_request_args` - arguments handed to `wp_remote_post()`.
* `volade_request_body` - payload sent to api.volade.com, before it is encoded.
* `volade_premium_result` - the entitlement returned after the API answered, before it is cached.
* `volade_premium_checked` - action fired when a check reached the API and was cached (`$is_premium`). Not fired when the answer came from the cache.
* `volade_upgrade_url` - the off-site upgrade link.
* `volade_export_payload` - the settings download, before it is streamed.
* `volade_option_updated` - fired when one of the plugin's own options changes (`$option, $old_value, $value`).
* `volade_settings_imported`, `volade_settings_restored` - fired after a backup import or a restore to defaults.
* `volade_before_render`, `volade_after_render` - wrap every Volade screen (`$view`).

Three WP-CLI commands are available too: `wp volade-breadcrumbs status` reads the stored state without any request, `wp volade-breadcrumbs test` performs a premium check, and `wp volade-breadcrumbs clear-cache` drops the cached result.

= Where are my settings backed up? =

Volade Breadcrumbs > Tools > Settings Backup. The export is a plain JSON file of this plugin's own options, produced on demand from your database. It contains your API and license keys, so treat it like a password. Import re-runs every value through the same sanitiser the Settings screen uses, so a tampered file cannot write an unsanitised value. Nothing in that screen contacts a server.

== External Services ==

This plugin connects to an external service to verify Premium entitlements. The connection happens only when you run a premium status check yourself from Volade Breadcrumbs > Tools. The plugin never contacts this service automatically, in the background or on a schedule, and rendering a screen or a breadcrumb trail never triggers an outbound request.

**Service provider:** Volade

**Service URL:** https://api.volade.com/

**What it is used for:** Verifying whether the current site holds an active Premium entitlement.

**Data sent:**

* Site URL (`home_url()`)
* Domain (host extracted from the site URL)
* Plugin version (`VOLADE_BREADCRUMBS_VERSION`)
* Plugin identifier (`volade-breadcrumbs`)
* Optional license key, only if one has been entered in Settings
* Optional `Authorization: Bearer` header, only if an API key has been entered in Settings

No personal user data, no email addresses, no payment data and no user identifiers are collected or transmitted by this plugin.

**When it is sent:** Only when a premium entitlement check is performed. Results are cached in a WordPress transient (1 hour on success, 5 minutes on failure) to minimize the number of requests.

**Terms of Service:** https://volade.com/en/terms.html

**Privacy Policy:** https://volade.com/en/privacy.html

== Screenshots ==

1. The Volade Breadcrumbs menu on the left of the dashboard, with an icon on every entry.
2. Overview screen: premium status, quick access and the Free vs Premium comparison.
3. Settings screen: the breadcrumb section above the shared API connection, with the four style previews.

== Changelog ==

= 1.0.0 =
* Initial release.
* Breadcrumb trail above the content of any public post type, with a shortcode for manual placement.
* "Breadcrumb trail" block for the editor and a widget for any widget area, both rendering through the same code path.
* `volade_breadcrumbs()` and `volade_breadcrumbs_json_ld()` template functions.
* Trails for categories, tags, custom taxonomies, post type archives, author archives and date archives.
* WooCommerce chain (shop, product categories, product tags, product) with an option to replace WooCommerce's own breadcrumb.
* Primary category honoured from Yoast SEO and Rank Math.
* Per-item switch in the editor to hide the trail on one page, and an option to hide the current page title.
* JSON-LD BreadcrumbList printed together with the trail.
* Four visual presets shown as live previews, configurable separator, homepage label, maximum depth and post type list.
* Accessibility and print polish: focus ring, reduced motion, higher contrast, phone-width wrapping.
* 17-language interface with SVG flag icons, colour tokens taken from volade.com.
* Premium entitlement verified server-side via api.volade.com, with transient caching and graceful failure.
* Settings export, import and restore to defaults, plus a locally read System Information panel.
* "Getting started" checklist on the Overview.
* Actions and filters around the API call, the entitlement, the screens and the settings; `wp volade-breadcrumbs` WP-CLI commands.

== Upgrade Notice ==

= 1.0.0 =
Initial release.
