/**
 * Volade Breadcrumbs - block editor script.
 *
 * Plain JavaScript, no build step, no bundler and no third party code: it is
 * loaded straight from the plugin folder and registers one dynamic block.
 *
 * The editor draws a static preview using the very stylesheet the visitor
 * will get, and the actual trail is produced by PHP when the page is
 * displayed, so what is saved in a post can never contradict the settings.
 *
 * @package Volade
 */
( function ( blocks, element, blockEditor, i18n, components, data ) {
	'use strict';

	var el = element.createElement;
	var useBlockProps = blockEditor.useBlockProps;
	var InspectorControls = blockEditor.InspectorControls;
	var PanelBody = components.PanelBody;
	var SelectControl = components.SelectControl;
	var variants = [ 'default', 'minimal', 'pill', 'numbered' ];

	/**
	 * Never let a preview link take the editor anywhere.
	 *
	 * @param {Object} event Click event.
	 */
	function stay( event ) {
		event.preventDefault();
	}

	/**
	 * The title of the post being edited, for the preview's last crumb.
	 *
	 * @return {string}
	 */
	function currentTitle() {
		try {
			var post = data.select( 'core/editor' ).getCurrentPost();

			if ( post && post.title && typeof post.title.rendered === 'string' && post.title.rendered ) {
				return post.title.rendered;
			}
		} catch ( e ) {
			// No editor context (widgets screen, site editor): fall through.
		}

		return voladeBreadcrumbsBlock.untitled;
	}

	/**
	 * Draw one preview trail.
	 *
	 * Every class written here is also written by PHP in render(), which is
	 * what lets the class-coverage audit prove stylesheet and code agree.
	 *
	 * @param {string} style Style slug, empty for the saved setting.
	 * @return {Object} Element.
	 */
	function preview( style ) {
		var variant = style && -1 !== variants.indexOf( style ) ? style : 'default';
		var blockProps = useBlockProps( { className: 'volade-bc volade-bc--' + variant } );
		var items = [ voladeBreadcrumbsBlock.home, currentTitle() ];

		return el( 'div', blockProps,
			el( 'ol', { className: 'volade-bc-list' },
				items.map( function ( label, index ) {
					var last = index === items.length - 1;

					return el( 'li', { className: 'volade-bc-item', key: index },
						last
							? el( 'span', { className: 'volade-bc-current' }, label )
							: el(
								'a',
								{
									className: 'volade-bc-link',
									href: '#',
									onClick: stay
								},
								label
							),
						last
							? null
							: el(
								'span',
								{ className: 'volade-bc-sep', 'aria-hidden': 'true' },
								voladeBreadcrumbsBlock.separator
							)
					);
				} )
			)
		);
	}

	blocks.registerBlockType( 'volade/breadcrumbs', {
		apiVersion: 2,
		title: voladeBreadcrumbsBlock.title,
		description: voladeBreadcrumbsBlock.description,
		category: 'widgets',
		icon: 'admin-site-alt3',
		attributes: {
			style: {
				type: 'string',
				default: ''
			}
		},
		supports: {
			html: false,
			multiple: false
		},
		edit: function ( props ) {
			var style = props.attributes.style;

			return [
				el( InspectorControls, { key: 'inspector' },
					el( PanelBody, { title: voladeBreadcrumbsBlock.settings, initialOpen: true },
						el( SelectControl, {
							label: voladeBreadcrumbsBlock.settings,
							value: style,
							options: voladeBreadcrumbsBlock.styles,
							onChange: function ( value ) {
								props.setAttributes( { style: value } );
							}
						} )
					)
				),
				preview( style )
			];
		},
		save: function () {
			return null;
		}
	} );
} )(
	window.wp.blocks,
	window.wp.element,
	window.wp.blockEditor,
	window.wp.i18n,
	window.wp.components,
	window.wp.data
);
