/**
 * Volade Admin JS.
 *
 * Loaded only on the Volade screens (see Volade_Breadcrumbs_Admin::enqueue_assets).
 * No jQuery dependency, no network call, no timers: just the live selection
 * feedback for the language grid, which is rendered server-side on first paint
 * and only re-renders when the settings are saved.
 */
(function () {
	'use strict';

	/**
	 * Move the .is-selected marker to the label that owns the active radio.
	 *
	 * @param {HTMLElement} grid Language grid fieldset.
	 */
	function highlight(grid) {
		var labels = grid.querySelectorAll('.volade-lang');
		var active = grid.querySelector('input[type="radio"]:checked');
		var i;
		var owner = null;

		if (active) {
			owner = active.closest ? active.closest('.volade-lang') : null;
		}

		for (i = 0; i < labels.length; i++) {
			if (labels[i] === owner) {
				labels[i].classList.add('is-selected');
			} else {
				labels[i].classList.remove('is-selected');
			}
		}
	}

	function init() {
		var grids = document.querySelectorAll('.volade-lang-grid');
		var i;

		for (i = 0; i < grids.length; i++) {
			(function (grid) {
				grid.addEventListener('change', function () {
					highlight(grid);
				});
			})(grids[i]);
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
