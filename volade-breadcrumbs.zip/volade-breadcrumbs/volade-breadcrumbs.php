<?php
/**
 * Plugin Name:       Volade Breadcrumbs
 * Description:       Adds a breadcrumb trail to your content and a BreadcrumbList schema for search engines, with Premium entitlement verification via the Volade API.
 * Version:           1.0.0
 * Author:            Volade
 * Author URI:        https://volade.com/
 * License:           GPL-2.0+
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       volade-breadcrumbs
 * Domain Path:       /languages
 * Requires PHP:      7.4
 * Requires at least: 6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define constants.
define( 'VOLADE_BREADCRUMBS_VERSION', '1.0.0' );
define( 'VOLADE_BREADCRUMBS_PLUGIN_FILE', __FILE__ );
// Slugged path used by core's update system (volade-breadcrumbs/volade-breadcrumbs.php).
define( 'VOLADE_BREADCRUMBS_PLUGIN_BASE', plugin_basename( __FILE__ ) );
define( 'VOLADE_BREADCRUMBS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'VOLADE_BREADCRUMBS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Autoload includes.
require_once VOLADE_BREADCRUMBS_PLUGIN_DIR . 'includes/class-volade-breadcrumbs-api.php';
require_once VOLADE_BREADCRUMBS_PLUGIN_DIR . 'includes/class-volade-breadcrumbs-premium.php';
require_once VOLADE_BREADCRUMBS_PLUGIN_DIR . 'includes/class-volade-breadcrumbs-i18n.php';
require_once VOLADE_BREADCRUMBS_PLUGIN_DIR . 'includes/class-volade-breadcrumbs-tools.php';
require_once VOLADE_BREADCRUMBS_PLUGIN_DIR . 'includes/class-volade-breadcrumbs-admin.php';
// The front-end half: trail, shortcode and structured data.
require_once VOLADE_BREADCRUMBS_PLUGIN_DIR . 'includes/class-volade-breadcrumbs-trail.php';
// The two placements a shortcode cannot reach: the inserter and widget areas.
require_once VOLADE_BREADCRUMBS_PLUGIN_DIR . 'includes/class-volade-breadcrumbs-block.php';
require_once VOLADE_BREADCRUMBS_PLUGIN_DIR . 'includes/class-volade-breadcrumbs-widget.php';
// Loaded last: it registers itself with WP-CLI only when that is defined.
require_once VOLADE_BREADCRUMBS_PLUGIN_DIR . 'includes/class-volade-breadcrumbs-cli.php';

/*
 * Both are wired up here rather than from Volade_Breadcrumbs::init(): that
 * method runs *inside* the init action, and widgets_init has already fired by
 * then, so a widget hooked there would never be registered.
 */
Volade_Breadcrumbs_Block::hooks();
Volade_Breadcrumbs_Widget::hooks();

/**
 * Plugin activation.
 *
 * Sets sensible defaults without outputting notices.
 */
function volade_breadcrumbs_activate() {
	if ( false === get_option( 'volade_api_base_url' ) ) {
		update_option( 'volade_api_base_url', Volade_Breadcrumbs_API::DEFAULT_API_BASE );
	}

	if ( false === get_option( 'volade_premium_endpoint' ) ) {
		update_option( 'volade_premium_endpoint', 'premium/check' );
	}

	if ( false === get_option( 'volade_upgrade_url' ) ) {
		update_option( 'volade_upgrade_url', 'https://volade.com/' );
	}

	if ( false === get_option( Volade_Breadcrumbs_I18n::OPTION ) ) {
		update_option( Volade_Breadcrumbs_I18n::OPTION, '' );
	}

	// Clear any stale premium cache on activation.
	delete_transient( 'volade_bc_premium_status' );
}
register_activation_hook( VOLADE_BREADCRUMBS_PLUGIN_FILE, 'volade_breadcrumbs_activate' );

/**
 * Plugin deactivation.
 *
 * Clean up temporary cached data only (no options removed).
 */
function volade_breadcrumbs_deactivate() {
	delete_transient( 'volade_bc_premium_status' );
}
register_deactivation_hook( VOLADE_BREADCRUMBS_PLUGIN_FILE, 'volade_breadcrumbs_deactivate' );

/**
 * Main plugin class.
 */
final class Volade_Breadcrumbs {

	/**
	 * @var Volade_Breadcrumbs
	 */
	private static $instance;

	/**
	 * @return Volade
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		/*
		 * The textdomain has to be loaded before widgets register
		 * themselves: widgets_init runs at init priority 1, and a widget
		 * that builds its name and description before the translations are
		 * in place would show them in English forever. Loading at priority 0
		 * still happens inside init, which is what WordPress 6.7 asks for,
		 * and it leaves every other component below untouched.
		 */
		add_action( 'init', array( 'Volade_Breadcrumbs_I18n', 'load_textdomain' ), 0 );
		add_action( 'init', array( $this, 'init' ) );
	}

	/**
	 * Init components.
	 */
	public function init() {
		Volade_Breadcrumbs_Trail::hooks();
		Volade_Breadcrumbs_Admin::instance();
		Volade_Breadcrumbs_Premium::instance();
	}
}

/*
 * Bootstrap plugin.
 *
 * Deliberately no volade_breadcrumbs() wrapper here: that exact name is the
 * public template function declared in the trail file, and redeclaring it is
 * a fatal error the moment WordPress includes this plugin.
 */
Volade_Breadcrumbs::instance();
